import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";

// Next.js 16 "proxy" (formerly middleware): gate /admin before any page renders.
export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname === "/admin/login") return NextResponse.next();
  const token = req.cookies.get("av_session")?.value;
  const secret = process.env.AUTH_SECRET;
  let ok = false;
  if (token && secret && secret.length >= 32) {
    try { await jwtVerify(token, new TextEncoder().encode(secret)); ok = true; } catch {}
  }
  if (!ok) return NextResponse.redirect(new URL("/admin/login", req.url));
  const res = NextResponse.next();
  res.headers.set("Cache-Control", "no-store");
  res.headers.set("X-Robots-Tag", "noindex, nofollow");
  return res;
}

export const config = { matcher: ["/admin/:path*"] };
