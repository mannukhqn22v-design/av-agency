"use client";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";

export function Loader() {
  const [show, setShow] = useState(true);
  useEffect(() => {
    let seen = false;
    try { seen = sessionStorage.getItem("av-loaded") === "1"; } catch {}
    if (seen) { setShow(false); return; }
    const t = setTimeout(() => {
      setShow(false);
      try { sessionStorage.setItem("av-loaded", "1"); } catch {}
    }, 1100);
    return () => clearTimeout(t);
  }, []);
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="loader"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[100] grid place-items-center bg-[#080a0d]"
          aria-hidden
        >
          <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.7 }} className="flex flex-col items-center gap-5">
            <Image src="/brand/av-logo.png" alt="" width={96} height={94} className="rounded-2xl shadow-[0_0_60px_rgba(0,140,255,0.35)]" priority />
            <div className="h-0.5 w-40 overflow-hidden rounded bg-white/10">
              <motion.div initial={{ x: "-100%" }} animate={{ x: "100%" }} transition={{ duration: 1, repeat: Infinity }} className="h-full w-1/2 bg-gradient-to-r from-transparent via-[#00b7ff] to-transparent" />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
