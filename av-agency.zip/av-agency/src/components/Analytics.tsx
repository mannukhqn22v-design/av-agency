"use client";
import Script from "next/script";
import { useEffect, useState } from "react";

type Ids = { ga?: string; gtm?: string; pixel?: string };
const KEY = "av-consent";

export function Analytics({ ids }: { ids: Ids }) {
  const configured = Boolean(ids.ga || ids.gtm || ids.pixel);
  const [consent, setConsent] = useState<"granted" | "denied" | "unset">("unset");
  useEffect(() => {
    try { const v = localStorage.getItem(KEY); if (v === "granted" || v === "denied") setConsent(v); } catch {}
  }, []);
  if (!configured) return null; // nothing loads until IDs are configured
  const choose = (v: "granted" | "denied") => { setConsent(v); try { localStorage.setItem(KEY, v); } catch {} };
  return (
    <>
      {consent === "granted" && (
        <>
          {ids.ga && (<>
            <Script src={`https://www.googletagmanager.com/gtag/js?id=${ids.ga}`} strategy="afterInteractive" />
            <Script id="ga4" strategy="afterInteractive">{`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${ids.ga}');`}</Script>
          </>)}
          {ids.gtm && <Script id="gtm" strategy="afterInteractive">{`(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${ids.gtm}');`}</Script>}
          {ids.pixel && <Script id="fbq" strategy="afterInteractive">{`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${ids.pixel}');fbq('track','PageView');`}</Script>}
        </>
      )}
      {consent === "unset" && (
        <div role="dialog" aria-label="Cookie consent" className="glass fixed bottom-4 left-4 right-4 z-[60] mx-auto max-w-xl rounded-2xl p-4 shadow-2xl">
          <p className="text-sm text-soft">We use analytics and advertising cookies only with your consent to understand how the site is used.</p>
          <div className="mt-3 flex gap-2">
            <button className="btn btn-primary !py-2" onClick={() => choose("granted")}>Accept</button>
            <button className="btn btn-ghost !py-2" onClick={() => choose("denied")}>Decline</button>
          </div>
        </div>
      )}
    </>
  );
}
