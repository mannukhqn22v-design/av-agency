import Link from "next/link";
import { Mail, MapPin } from "lucide-react";
import { SITE } from "@/lib/site";
import { Logo } from "./Logo";

const cols = [
  { title: "Services", links: [["SEO", "/services/seo"], ["Google Ads", "/services/google-ads"], ["Meta Ads", "/services/meta-ads"], ["B2B Lead Generation", "/services/b2b-lead-generation"], ["Analytics & Reporting", "/services/analytics-reporting"]] },
  { title: "Company", links: [["About", "/about"], ["Portfolio", "/portfolio"], ["Pricing", "/pricing"], ["Blog", "/blog"], ["Contact", "/contact"]] },
];

export function Footer() {
  return (
    <footer className="border-t border-line bg-surface/40">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo size={48} />
          <p className="mt-4 max-w-md text-sm text-muted">{SITE.tagline} Founder-led SEO, performance marketing and B2B lead research from New Delhi.</p>
          <ul className="mt-5 space-y-2 text-sm text-soft">
            <li className="flex items-center gap-2"><Mail size={16} className="text-accent" /> <a href={`mailto:${SITE.email}`} className="hover:text-accent">{SITE.email}</a></li>
            <li className="flex items-center gap-2"><MapPin size={16} className="text-accent" /> {SITE.location}</li>
          </ul>
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-widest text-muted">{c.title}</h3>
            <ul className="space-y-2.5 text-sm">
              {c.links.map(([l, h]) => (
                <li key={h}><Link href={h} className="text-soft hover:text-accent">{l}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-muted">
        © {new Date().getFullYear()} {SITE.name}. All rights reserved. Portfolio items marked &quot;Practice Project&quot; are not paid client work.
      </div>
    </footer>
  );
}
