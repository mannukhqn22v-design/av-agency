import Link from "next/link";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";
import { SITE } from "@/lib/site";

export function JsonLd({ data }: { data: object }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }} />;
}

export function Breadcrumbs({ items }: { items: { name: string; href: string }[] }) {
  const all = [{ name: "Home", href: "/" }, ...items];
  return (
    <>
      <nav aria-label="Breadcrumb" className="mb-4">
        <ol className="flex flex-wrap items-center gap-1 text-xs text-muted">
          {all.map((b, i) => (
            <li key={b.href} className="flex items-center gap-1">
              {i > 0 && <ChevronRight size={12} />}
              {i === all.length - 1 ? <span aria-current="page" className="text-soft">{b.name}</span> : <Link href={b.href} className="hover:text-accent">{b.name}</Link>}
            </li>
          ))}
        </ol>
      </nav>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: all.map((b, i) => ({ "@type": "ListItem", position: i + 1, name: b.name, item: SITE.url + b.href })) }} />
    </>
  );
}

export function PageHero({ title, intro, crumbs, children }: { title: string; intro?: string; crumbs?: { name: string; href: string }[]; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden pt-36 pb-16">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60" />
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-[40rem] -translate-x-1/2 rounded-full bg-accent/15 blur-[120px]" />
      <div className="relative mx-auto max-w-5xl px-5">
        {crumbs && <Breadcrumbs items={crumbs} />}
        <h1 className="font-display text-4xl font-bold leading-tight md:text-6xl">{title}</h1>
        {intro && <p className="mt-5 max-w-3xl text-lg text-muted">{intro}</p>}
        {children}
      </div>
    </section>
  );
}

export function Section({ id, title, kicker, intro, children, className = "" }: { id?: string; title?: string; kicker?: string; intro?: string; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={`mx-auto max-w-7xl px-5 py-16 ${className}`}>
      {(title || kicker) && (
        <div className="mb-10 max-w-3xl">
          {kicker && <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-accent">{kicker}</p>}
          {title && <h2 className="font-display text-3xl font-bold md:text-4xl">{title}</h2>}
          {intro && <p className="mt-3 text-muted">{intro}</p>}
        </div>
      )}
      {children}
    </section>
  );
}

export function Faq({ items, schema = false }: { items: { q: string; a: string }[]; schema?: boolean }) {
  return (
    <div className="mx-auto max-w-3xl space-y-3">
      {items.map((f) => (
        <details key={f.q} className="card group !transform-none p-5 open:border-accent/50">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">
            {f.q}
            <span className="text-accent transition group-open:rotate-45">+</span>
          </summary>
          <p className="mt-3 text-sm leading-relaxed text-muted">{f.a}</p>
        </details>
      ))}
      {schema && <JsonLd data={{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: items.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) }} />}
    </div>
  );
}

export function Badge({ children, tone = "accent" }: { children: ReactNode; tone?: "accent" | "warn" | "muted" }) {
  const c = tone === "warn" ? "border-amber-400/50 text-amber-500" : tone === "muted" ? "border-line text-muted" : "border-accent/50 text-accent";
  return <span className={`inline-block rounded-full border px-3 py-1 text-[11px] font-semibold uppercase tracking-wider ${c}`}>{children}</span>;
}

export function renderMarkdown(md: string) {
  const blocks = md.split(/\n{2,}/);
  return blocks.map((b, i) => {
    const t = b.trim();
    if (t.startsWith("## ")) {
      const [head, ...rest] = t.split("\n");
      return (
        <div key={i}>
          <h2>{head.slice(3)}</h2>
          {rest.length > 0 && renderMarkdown(rest.join("\n"))}
        </div>
      );
    }
    if (t.startsWith("### ")) return <h3 key={i}>{t.slice(4)}</h3>;
    const lines = t.split("\n");
    if (lines.every((l) => l.startsWith("- "))) return <ul key={i}>{lines.map((l, j) => <li key={j}>{l.slice(2)}</li>)}</ul>;
    return <p key={i}>{t}</p>;
  });
}
