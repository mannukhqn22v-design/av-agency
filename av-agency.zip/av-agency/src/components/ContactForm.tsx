"use client";
import { useRef, useState } from "react";
import { CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { SERVICE_OPTIONS } from "@/lib/site";

type State = { status: "idle" | "sending" | "ok" | "error"; message?: string; fields?: Record<string, string> };

export function ContactForm({ defaultService = "" }: { defaultService?: string }) {
  const [state, setState] = useState<State>({ status: "idle" });
  const started = useRef(Date.now());
  const locked = useRef(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (locked.current) return; // prevents duplicate submissions
    locked.current = true;
    setState({ status: "sending" });
    const fd = Object.fromEntries(new FormData(e.currentTarget).entries()) as Record<string, string>;
    try {
      const res = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...fd, startedAt: started.current }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        setState({ status: "ok", message: data.message });
        (e.target as HTMLFormElement).reset();
      } else {
        locked.current = false;
        setState({ status: "error", message: data.error || "Something went wrong. Please try again.", fields: data.fields });
      }
    } catch {
      locked.current = false;
      setState({ status: "error", message: "Network error. Please check your connection and try again." });
    }
  }

  if (state.status === "ok")
    return (
      <div role="status" className="card !transform-none p-8 text-center">
        <CheckCircle2 className="mx-auto mb-3 text-emerald-500" size={44} />
        <h3 className="font-display text-2xl font-bold">Enquiry received</h3>
        <p className="mt-2 text-muted">{state.message}</p>
      </div>
    );

  const err = (k: string) => state.fields?.[k] && <p className="mt-1 text-xs text-red-500">{state.fields[k]}</p>;

  return (
    <form onSubmit={onSubmit} className="card !transform-none space-y-4 p-6 md:p-8" noValidate>
      {state.status === "error" && (
        <div role="alert" className="flex items-start gap-2 rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-500">
          <AlertCircle size={18} className="mt-0.5 shrink-0" /> {state.message}
        </div>
      )}
      <div className="grid gap-4 md:grid-cols-2">
        <div><label htmlFor="name" className="mb-1 block text-sm font-medium">Name *</label><input id="name" name="name" required autoComplete="name" className="field" />{err("name")}</div>
        <div><label htmlFor="email" className="mb-1 block text-sm font-medium">Business email *</label><input id="email" name="email" type="email" required autoComplete="email" className="field" />{err("email")}</div>
        <div><label htmlFor="company" className="mb-1 block text-sm font-medium">Company name</label><input id="company" name="company" autoComplete="organization" className="field" />{err("company")}</div>
        <div><label htmlFor="websiteUrl" className="mb-1 block text-sm font-medium">Website URL</label><input id="websiteUrl" name="websiteUrl" type="url" placeholder="https://" className="field" />{err("websiteUrl")}</div>
        <div>
          <label htmlFor="service" className="mb-1 block text-sm font-medium">Service interested in *</label>
          <select id="service" name="service" required defaultValue={defaultService} className="field">
            <option value="" disabled>Select a service</option>
            {SERVICE_OPTIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
          {err("service")}
        </div>
        <div>
          <label htmlFor="budget" className="mb-1 block text-sm font-medium">Monthly marketing budget (optional)</label>
          <select id="budget" name="budget" defaultValue="" className="field">
            <option value="">Prefer not to say</option>
            <option>Below ₹10,000</option><option>₹10,000 – ₹25,000</option><option>₹25,000 – ₹75,000</option><option>₹75,000+</option>
          </select>
        </div>
      </div>
      <div><label htmlFor="message" className="mb-1 block text-sm font-medium">Project requirements *</label><textarea id="message" name="message" required rows={5} className="field" />{err("message")}</div>
      <fieldset>
        <legend className="mb-2 text-sm font-medium">Preferred contact method</legend>
        <div className="flex flex-wrap gap-4 text-sm">
          {[["EMAIL", "Email"], ["WHATSAPP", "WhatsApp"], ["PHONE", "Phone call"]].map(([v, l], i) => (
            <label key={v} className="flex items-center gap-2"><input type="radio" name="contactMethod" value={v} defaultChecked={i === 0} className="accent-[var(--accent)]" /> {l}</label>
          ))}
        </div>
      </fieldset>
      {/* honeypot: hidden from users and assistive tech */}
      <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label>Leave this empty<input name="hp" tabIndex={-1} autoComplete="off" /></label>
      </div>
      <button type="submit" disabled={state.status === "sending"} className="btn btn-primary w-full disabled:opacity-60">
        {state.status === "sending" ? <><Loader2 className="animate-spin" size={18} /> Sending…</> : "Request Free Consultation"}
      </button>
      <p className="text-xs text-muted">We use your details only to respond to this enquiry.</p>
    </form>
  );
}
