import Image from "next/image";
import Link from "next/link";

// Uses the exact supplied AV monogram, with its original 863x843 proportions.
export function Logo({ size = 40, withText = true }: { size?: number; withText?: boolean }) {
  const h = Math.round((size * 843) / 863);
  return (
    <Link href="/" className="flex items-center gap-3" aria-label="Aakash Verma Digital Agency home">
      <Image src="/brand/av-logo.png" alt="AV monogram logo" width={size} height={h} className="rounded-lg" priority />
      {withText && (
        <span className="hidden leading-tight sm:block">
          <span className="block font-display text-sm font-bold tracking-wide">AAKASH VERMA</span>
          <span className="block text-[10px] tracking-[0.25em] text-muted">DIGITAL AGENCY</span>
        </span>
      )}
    </Link>
  );
}
