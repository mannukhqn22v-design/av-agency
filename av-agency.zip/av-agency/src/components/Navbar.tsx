"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, Menu, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { NAV } from "@/lib/site";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";

export function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [dd, setDd] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const ddRef = useRef<HTMLLIElement>(null);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 12);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => {
    setOpen(false);
    setDd(false);
  }, [pathname]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        setDd(false);
      }
    };
    const onClick = (e: MouseEvent) => {
      if (ddRef.current && !ddRef.current.contains(e.target as Node)) setDd(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, []);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  const active = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all ${scrolled ? "glass shadow-lg" : "bg-transparent"}`}>
      <nav className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5" aria-label="Main navigation">
        <Logo />
        <ul className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) =>
            "children" in item ? (
              <li key={item.label} className="relative" ref={ddRef}>
                <button
                  type="button"
                  aria-expanded={dd}
                  aria-haspopup="menu"
                  onClick={() => setDd((v) => !v)}
                  className={`flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium hover:text-accent ${pathname.startsWith("/services") ? "text-accent" : "text-soft"}`}
                >
                  {item.label} <ChevronDown size={14} className={`transition ${dd ? "rotate-180" : ""}`} />
                </button>
                <AnimatePresence>
                  {dd && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 8 }}
                      className="glass absolute left-0 top-full mt-2 w-80 rounded-2xl p-2 shadow-2xl"
                      role="menu"
                    >
                      {item.children.map((c) => (
                        <Link key={c.href} href={c.href} role="menuitem" className="block rounded-xl px-4 py-3 hover:bg-accent/10">
                          <span className="block text-sm font-semibold">{c.label}</span>
                          <span className="block text-xs text-muted">{c.desc}</span>
                        </Link>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </li>
            ) : (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={active(item.href) ? "page" : undefined}
                  className={`rounded-lg px-3 py-2 text-sm font-medium hover:text-accent ${active(item.href) ? "text-accent" : "text-soft"}`}
                >
                  {item.label}
                </Link>
              </li>
            ),
          )}
        </ul>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link href="/contact" className="btn btn-primary hidden !py-2.5 sm:inline-flex">
            Get a Quote
          </Link>
          <button
            type="button"
            className="grid h-10 w-10 place-items-center rounded-xl border border-line lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="mobile-drawer"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 top-[72px] bg-black/60 lg:hidden" onClick={() => setOpen(false)} />
            <motion.div
              id="mobile-drawer"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.28 }}
              className="fixed right-0 top-[72px] h-[calc(100dvh-72px)] w-[85%] max-w-sm overflow-y-auto border-l border-line bg-bg p-5 lg:hidden"
            >
              <ul className="space-y-1">
                {NAV.map((item) =>
                  "children" in item ? (
                    <li key={item.label}>
                      <p className="px-3 pb-1 pt-3 text-xs font-semibold uppercase tracking-widest text-muted">{item.label}</p>
                      {item.children.map((c) => (
                        <Link key={c.href} href={c.href} className="block rounded-xl px-3 py-2.5 text-soft hover:bg-accent/10">
                          {c.label}
                        </Link>
                      ))}
                    </li>
                  ) : (
                    <li key={item.href}>
                      <Link href={item.href} className="block rounded-xl px-3 py-2.5 font-medium hover:bg-accent/10">
                        {item.label}
                      </Link>
                    </li>
                  ),
                )}
              </ul>
              <Link href="/contact" className="btn btn-primary mt-6 w-full">
                Get a Quote
              </Link>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
