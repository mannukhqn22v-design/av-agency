"use client";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Environment, Lightformer, Sparkles, RoundedBox } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { LOGO_H, LOGO_HOLES, LOGO_OUTER, LOGO_W } from "@/lib/logo-shape";

const S = 2.6 / LOGO_W;
const toV = (p: [number, number]) => new THREE.Vector2((p[0] - LOGO_W / 2) * S, -(p[1] - LOGO_H / 2) * S);

function Monogram() {
  const geo = useMemo(() => {
    const shape = new THREE.Shape(LOGO_OUTER.map(toV));
    LOGO_HOLES.forEach((h) => shape.holes.push(new THREE.Path(h.map(toV))));
    const g = new THREE.ExtrudeGeometry(shape, { depth: 0.28, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.02, bevelSegments: 3 });
    g.center();
    return g;
  }, []);
  return (
    <mesh geometry={geo} castShadow>
      <meshStandardMaterial color="#e8ebef" metalness={0.75} roughness={0.28} envMapIntensity={2.2} emissive="#8a93a0" emissiveIntensity={0.18} />
    </mesh>
  );
}

function Bars() {
  const refs = useRef<THREE.Mesh[]>([]);
  const heights = [0.5, 0.8, 0.65, 1.1, 1.4, 1.8];
  useFrame(({ clock }) => {
    refs.current.forEach((m, i) => {
      if (!m) return;
      const t = (Math.sin(clock.elapsedTime * 0.9 + i * 0.7) + 1) / 2;
      const h = heights[i] * (0.85 + t * 0.15);
      m.scale.y = h;
      m.position.y = h / 2;
    });
  });
  return (
    <group position={[2.1, -1.2, 0.2]} rotation={[0, -0.5, 0]}>
      {heights.map((_, i) => (
        <mesh key={i} ref={(el) => { if (el) refs.current[i] = el; }} position={[i * 0.3, 0.5, 0]}>
          <boxGeometry args={[0.2, 1, 0.2]} />
          <meshStandardMaterial color={i === heights.length - 1 ? "#00b7ff" : "#008cff"} emissive="#008cff" emissiveIntensity={0.45} metalness={0.4} roughness={0.3} />
        </mesh>
      ))}
    </group>
  );
}

function Arrow() {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (ref.current) ref.current.position.y = 1.5 + Math.sin(clock.elapsedTime * 1.2) * 0.12;
  });
  return (
    <group ref={ref} position={[2.4, 1.5, 0]} rotation={[0, -0.4, -0.7]}>
      <mesh>
        <cylinderGeometry args={[0.05, 0.05, 1.2, 16]} />
        <meshStandardMaterial color="#00b7ff" emissive="#00b7ff" emissiveIntensity={0.9} />
      </mesh>
      <mesh position={[0, 0.7, 0]}>
        <coneGeometry args={[0.18, 0.35, 24]} />
        <meshStandardMaterial color="#00b7ff" emissive="#00b7ff" emissiveIntensity={0.9} />
      </mesh>
    </group>
  );
}

function Laptop() {
  return (
    <Float speed={1.4} floatIntensity={0.6} rotationIntensity={0.25}>
      <group position={[-2.4, -1.1, 0.4]} rotation={[0.05, 0.55, 0]} scale={0.9}>
        <RoundedBox args={[1.7, 0.08, 1.15]} radius={0.03} position={[0, 0, 0]}>
          <meshStandardMaterial color="#858b94" metalness={0.9} roughness={0.3} />
        </RoundedBox>
        <group position={[0, 0.55, -0.55]} rotation={[-0.2, 0, 0]}>
          <RoundedBox args={[1.7, 1.1, 0.06]} radius={0.03}>
            <meshStandardMaterial color="#25282d" metalness={0.8} roughness={0.35} />
          </RoundedBox>
          <mesh position={[0, 0, 0.035]}>
            <planeGeometry args={[1.55, 0.95]} />
            <meshStandardMaterial color="#06131f" emissive="#008cff" emissiveIntensity={0.25} />
          </mesh>
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[-0.55 + i * 0.27, -0.25 + (i * 0.09 + 0.1) / 2, 0.04]}>
              <planeGeometry args={[0.15, 0.1 + i * 0.09]} />
              <meshBasicMaterial color={i === 4 ? "#00b7ff" : "#008cff"} />
            </mesh>
          ))}
        </group>
      </group>
    </Float>
  );
}

function Bubbles() {
  const pts = useMemo(() => Array.from({ length: 7 }, (_, i) => ({ p: [Math.cos(i * 0.9) * 3.1, Math.sin(i * 1.7) * 1.8, -1 - (i % 3) * 0.4] as [number, number, number], r: 0.1 + (i % 3) * 0.05 })), []);
  return (
    <>
      {pts.map((b, i) => (
        <Float key={i} speed={1 + i * 0.15} floatIntensity={1.2}>
          <mesh position={b.p}>
            <sphereGeometry args={[b.r, 24, 24]} />
            <meshStandardMaterial color="#00b7ff" emissive="#008cff" emissiveIntensity={0.7} transparent opacity={0.8} />
          </mesh>
        </Float>
      ))}
    </>
  );
}

function Rig({ children }: { children: React.ReactNode }) {
  const g = useRef<THREE.Group>(null);
  useFrame(({ pointer, clock }) => {
    if (!g.current) return;
    g.current.rotation.y = THREE.MathUtils.lerp(g.current.rotation.y, pointer.x * 0.35 + Math.sin(clock.elapsedTime * 0.4) * 0.15, 0.05);
    g.current.rotation.x = THREE.MathUtils.lerp(g.current.rotation.x, -pointer.y * 0.18, 0.05);
  });
  return <group ref={g}>{children}</group>;
}

export default function HeroScene() {
  return (
    <Canvas dpr={[1, 1.6]} camera={{ position: [0, 0, 9.5], fov: 42 }} gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}>
      <ambientLight intensity={1.1} />
      <directionalLight position={[4, 5, 5]} intensity={1.6} />
      <pointLight position={[-4, -2, 3]} intensity={18} color="#008cff" />
      {/* Procedural studio lighting: no remote HDR download, so it works offline and loads fast */}
      <Environment resolution={256}>
        <Lightformer form="rect" intensity={5} position={[0, 4, 3]} scale={[10, 3, 1]} color="#ffffff" />
        <Lightformer form="rect" intensity={4} position={[0, 0, 6]} scale={[8, 5, 1]} color="#ffffff" />
        <Lightformer form="rect" intensity={2} position={[-5, 0, 2]} rotation-y={Math.PI / 2} scale={[6, 3, 1]} color="#00b7ff" />
        <Lightformer form="rect" intensity={2} position={[5, 1, 2]} rotation-y={-Math.PI / 2} scale={[6, 3, 1]} color="#d9dde2" />
        <Lightformer form="ring" intensity={1.5} position={[0, -3, 4]} scale={4} color="#008cff" />
      </Environment>
      <Rig>
        <Float speed={1.2} floatIntensity={0.5} rotationIntensity={0.15}>
          <group scale={1.45}><Monogram /></group>
        </Float>
        <Bars />
        <Arrow />
        <Laptop />
        <Bubbles />
      </Rig>
      <Sparkles count={70} scale={[9, 5, 4]} size={2.5} speed={0.35} color="#00b7ff" />
    </Canvas>
  );
}
