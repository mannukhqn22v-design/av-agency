"use client";
import dynamic from "next/dynamic";
import Image from "next/image";
import { useEffect, useState } from "react";

const HeroScene = dynamic(() => import("./HeroScene"), { ssr: false });

function webglOk() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

export function Hero3D() {
  const [mode, setMode] = useState<"loading" | "3d" | "static">("loading");
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const small = window.innerWidth < 768;
    const weak = (navigator.hardwareConcurrency || 4) <= 2;
    setMode(reduce || small || weak || !webglOk() ? "static" : "3d");
  }, []);

  return (
    <div className="relative h-[380px] w-full md:h-[560px]" role="img" aria-label="3D AV monogram with analytics dashboard, ranking bars and growth arrow">
      <div className="pointer-events-none absolute inset-0 rounded-full bg-accent/20 blur-[110px]" />
      {mode === "3d" && <HeroScene />}
      {mode !== "3d" && (
        <div className="grid h-full place-items-center">
          <div className="floaty relative">
            <Image src="/brand/av-logo.png" alt="" width={240} height={234} className="rounded-3xl shadow-[0_0_80px_rgba(0,140,255,0.35)]" priority />
            <div className="glass absolute -bottom-6 -right-8 flex items-end gap-1.5 rounded-xl p-3">
              {[18, 28, 22, 40, 52].map((h, i) => (
                <span key={i} style={{ height: h }} className="w-2.5 rounded-sm bg-gradient-to-t from-accent to-accent2" />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
