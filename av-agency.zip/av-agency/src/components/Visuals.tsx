"use client";
import { motion, useInView } from "framer-motion";
import { useEffect, useRef, useState } from "react";

export function SampleTag({ text = "Sample / illustrative data" }: { text?: string }) {
  return <span className="rounded-full border border-amber-400/50 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-500">{text}</span>;
}

export function AnimatedBars({ data, label }: { data: { label: string; value: number }[]; label: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const max = Math.max(...data.map((d) => d.value));
  return (
    <div ref={ref} className="card !transform-none p-6" role="img" aria-label={label}>
      <div className="mb-5 flex items-center justify-between"><h3 className="font-semibold">{label}</h3><SampleTag /></div>
      <div className="flex h-48 items-end gap-3">
        {data.map((d, i) => (
          <div key={d.label} className="flex flex-1 flex-col items-center gap-2">
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: inView ? `${(d.value / max) * 100}%` : 0 }}
              transition={{ duration: 0.8, delay: i * 0.08 }}
              className="w-full rounded-t-md bg-gradient-to-t from-accent to-accent2"
            />
            <span className="text-[11px] text-muted">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function LineChart({ points, label }: { points: number[]; label: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const [hover, setHover] = useState<number | null>(null);
  const W = 400, H = 160, max = Math.max(...points), min = Math.min(...points);
  const xy = points.map((p, i) => [(i / (points.length - 1)) * W, H - 12 - ((p - min) / (max - min || 1)) * (H - 30)] as const);
  const d = xy.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  return (
    <div ref={ref} className="card !transform-none p-6">
      <div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">{label}</h3><SampleTag /></div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={label}>
        <defs>
          <linearGradient id="lg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--accent)" stopOpacity=".35" /><stop offset="1" stopColor="var(--accent)" stopOpacity="0" /></linearGradient>
        </defs>
        <path d={`${d} L${W},${H} L0,${H} Z`} fill="url(#lg)" />
        <motion.path d={d} fill="none" stroke="var(--accent-2)" strokeWidth="2.5" initial={{ pathLength: 0 }} animate={{ pathLength: inView ? 1 : 0 }} transition={{ duration: 1.4 }} />
        {xy.map(([x, y], i) => (
          <g key={i} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
            <circle cx={x} cy={y} r={10} fill="transparent" />
            <circle cx={x} cy={y} r={hover === i ? 5 : 3} fill="var(--accent-2)" />
          </g>
        ))}
      </svg>
      <p className="h-5 text-xs text-muted">{hover !== null ? `Point ${hover + 1}: ${points[hover]} (sample)` : "Hover a point to inspect"}</p>
    </div>
  );
}

export function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setN(to); return; }
    let raf = 0; const t0 = performance.now();
    const tick = (t: number) => { const p = Math.min((t - t0) / 1200, 1); setN(Math.round(to * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return <span ref={ref}>{n}{suffix}</span>;
}

export function CampaignFlow() {
  const steps = ["Objective", "Audience", "Creative", "Launch", "Measure", "Optimise"];
  return (
    <div className="card !transform-none p-6">
      <h3 className="mb-6 font-semibold">Campaign workflow</h3>
      <ol className="relative grid gap-4 md:grid-cols-6">
        {steps.map((s, i) => (
          <motion.li key={s} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.12 }} className="relative text-center">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-accent to-accent2 font-bold text-white shadow-[0_0_24px_rgba(0,140,255,.4)]">{i + 1}</div>
            <p className="mt-2 text-sm font-medium">{s}</p>
            {i < steps.length - 1 && <span className="absolute left-[calc(50%+32px)] top-6 hidden h-px w-[calc(100%-64px)] bg-gradient-to-r from-accent to-transparent md:block" />}
          </motion.li>
        ))}
      </ol>
    </div>
  );
}

export function LeadTable() {
  const rows = [
    ["Northwind Sample Co.", "Operations Head", "Manufacturing", "Delhi", "Verified"],
    ["Acme Demo Pvt Ltd", "Marketing Manager", "SaaS", "Gurugram", "Risky"],
    ["Example Retail LLP", "Founder", "Retail", "Noida", "Verified"],
    ["Sample Logistics Inc.", "Procurement Lead", "Logistics", "Mumbai", "Unverified"],
  ];
  const tone: Record<string, string> = { Verified: "text-emerald-500", Risky: "text-amber-500", Unverified: "text-muted" };
  return (
    <div className="card !transform-none overflow-hidden">
      <div className="flex items-center justify-between border-b border-line p-4"><h3 className="font-semibold">Lead database preview</h3><SampleTag text="Fictional sample data" /></div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="text-xs uppercase tracking-wider text-muted"><tr>{["Company", "Decision-maker role", "Industry", "City", "Email status"].map((h) => <th key={h} className="px-4 py-3">{h}</th>)}</tr></thead>
          <tbody>{rows.map((r) => (<tr key={r[0]} className="border-t border-line">{r.map((c, i) => <td key={i} className={`px-4 py-3 ${i === 4 ? `font-semibold ${tone[c]}` : ""}`}>{c}</td>)}</tr>))}</tbody>
        </table>
      </div>
    </div>
  );
}
