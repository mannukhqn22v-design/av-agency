"use client";
import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

export default function AdminLogin() {
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr("");
    const fd = Object.fromEntries(new FormData(e.currentTarget).entries());
    const r = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(fd) });
    if (r.ok) { router.replace("/admin"); router.refresh(); return; }
    setErr((await r.json().catch(() => ({}))).error || "Login failed"); setBusy(false);
  }
  return (
    <div className="grid min-h-screen place-items-center px-5">
      <form onSubmit={submit} className="card !transform-none w-full max-w-sm space-y-4 p-8">
        <Image src="/brand/av-logo.png" alt="AV logo" width={64} height={62} className="mx-auto rounded-xl" />
        <h1 className="text-center font-display text-xl font-bold">Admin sign in</h1>
        {err && <p role="alert" className="rounded-lg bg-red-500/10 p-2 text-center text-sm text-red-500">{err}</p>}
        <div><label htmlFor="email" className="mb-1 block text-sm">Email</label><input id="email" name="email" type="email" required autoComplete="username" className="field" /></div>
        <div><label htmlFor="password" className="mb-1 block text-sm">Password</label><input id="password" name="password" type="password" required autoComplete="current-password" className="field" /></div>
        <button disabled={busy} className="btn btn-primary w-full disabled:opacity-60">{busy ? "Signing in…" : "Sign in"}</button>
      </form>
    </div>
  );
}
