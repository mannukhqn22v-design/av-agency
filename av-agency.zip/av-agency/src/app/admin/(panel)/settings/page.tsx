import { getDb } from "@/lib/db";
import { saveSettings } from "../../actions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Website settings" };

export default async function Settings() {
  const s = (await getDb().siteSettings.findUnique({ where: { id: "singleton" } })) ?? { agencyName: "", tagline: "", contactEmail: "", whatsappNumber: "", location: "", linkedinUrl: "", instagramUrl: "", facebookUrl: "", gaId: "", gtmId: "", metaPixelId: "" };
  const f = (l: string, n: keyof typeof s, type = "text") => (<div><label className="mb-1 block text-sm" htmlFor={n}>{l}</label><input id={n} name={n} type={type} defaultValue={(s[n] as string | null) ?? ""} className="field" /></div>);
  return (<div className="max-w-2xl space-y-5"><h1 className="font-display text-2xl font-bold">Website settings</h1>
    <form action={saveSettings} className="card !transform-none space-y-4 p-5">
      {f("Agency name", "agencyName")}{f("Tagline", "tagline")}{f("Contact email", "contactEmail", "email")}{f("WhatsApp number (digits with country code)", "whatsappNumber")}{f("Location", "location")}
      {f("LinkedIn URL", "linkedinUrl", "url")}{f("Instagram URL", "instagramUrl", "url")}{f("Facebook URL", "facebookUrl", "url")}
      <h2 className="pt-2 font-semibold">Tracking IDs (activate only after visitor consent)</h2>
      {f("Google Analytics 4 ID (G-XXXX)", "gaId")}{f("Google Tag Manager ID (GTM-XXXX)", "gtmId")}{f("Meta Pixel ID", "metaPixelId")}
      <button className="btn btn-primary">Save settings</button></form>
    <p className="text-xs text-muted">Logo and favicon files live in /public/brand and src/app/icon.png (replace the files and redeploy). Upload other images in Media.</p></div>);
}
