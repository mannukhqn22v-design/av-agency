import { notFound } from "next/navigation";
import Link from "next/link";
import { getDb } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { deleteEnquiry, updateEnquiry } from "../../../actions";

export const dynamic = "force-dynamic";

export default async function Lead({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [r, s] = await Promise.all([getDb().contactEnquiry.findUnique({ where: { id } }), getSession()]);
  if (!r) notFound();
  const rows: [string, string | null][] = [["Email", r.email], ["Company", r.company], ["Website", r.websiteUrl], ["Service", r.service], ["Budget", r.budget], ["Preferred contact", r.contactMethod], ["Received", r.createdAt.toLocaleString("en-IN")]];
  return (
    <div className="max-w-3xl space-y-6">
      <Link href="/admin/leads" className="text-sm text-accent">← All leads</Link>
      <h1 className="font-display text-2xl font-bold">{r.name}</h1>
      <div className="card !transform-none p-5"><dl className="grid gap-3 text-sm sm:grid-cols-2">{rows.map(([k, v]) => <div key={k}><dt className="text-muted">{k}</dt><dd>{v || "-"}</dd></div>)}</dl><h2 className="mb-1 mt-5 text-sm font-semibold">Requirements</h2><p className="whitespace-pre-wrap text-sm text-soft">{r.message}</p></div>
      <form action={updateEnquiry} className="card !transform-none space-y-4 p-5"><input type="hidden" name="id" value={r.id} />
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="mb-1 block text-sm" htmlFor="status">Status</label><select id="status" name="status" defaultValue={r.status} className="field">{["NEW", "CONTACTED", "QUALIFIED", "PROPOSAL_SENT", "CONVERTED", "CLOSED"].map((x) => <option key={x} value={x}>{x.replace("_", " ")}</option>)}</select></div>
          <div><label className="mb-1 block text-sm" htmlFor="priority">Priority</label><select id="priority" name="priority" defaultValue={r.priority} className="field">{["LOW", "MEDIUM", "HIGH"].map((x) => <option key={x}>{x}</option>)}</select></div>
        </div>
        <div><label className="mb-1 block text-sm" htmlFor="notes">Internal notes</label><textarea id="notes" name="notes" rows={4} defaultValue={r.notes ?? ""} className="field" /></div>
        <button className="btn btn-primary">Save changes</button></form>
      {s?.role === "SUPER_ADMIN" && (
        <form action={deleteEnquiry} className="card !transform-none flex items-center justify-between gap-4 border-red-500/30 p-5"><input type="hidden" name="id" value={r.id} />
          <p className="text-sm text-muted">Permanently delete this enquiry.</p>
          <details className="relative"><summary className="btn btn-ghost !py-2 cursor-pointer list-none text-red-500">Delete…</summary><div className="absolute right-0 z-10 mt-2 w-60 rounded-xl border border-line bg-surface p-4 text-sm shadow-xl"><p className="mb-3">This cannot be undone. Confirm deletion?</p><button className="btn w-full bg-red-600 text-white">Yes, delete</button></div></details></form>)}
    </div>
  );
}
