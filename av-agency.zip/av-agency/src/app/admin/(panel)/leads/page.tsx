import Link from "next/link";
import { getDb } from "@/lib/db";
import type { EnquiryStatus, Priority } from "@/generated/prisma/client";

export const dynamic = "force-dynamic";
export const metadata = { title: "Leads" };
const STATUSES = ["NEW", "CONTACTED", "QUALIFIED", "PROPOSAL_SENT", "CONVERTED", "CLOSED"] as const;

export default async function Leads({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const status = typeof sp.status === "string" && (STATUSES as readonly string[]).includes(sp.status) ? (sp.status as EnquiryStatus) : undefined;
  const rows = await getDb().contactEnquiry.findMany({
    where: { ...(status && { status }), ...(q && { OR: [{ name: { contains: q, mode: "insensitive" } }, { email: { contains: q, mode: "insensitive" } }, { company: { contains: q, mode: "insensitive" } }] }) },
    orderBy: { createdAt: "desc" }, take: 200,
  });
  const tone: Record<Priority, string> = { HIGH: "text-red-500", MEDIUM: "text-amber-500", LOW: "text-muted" };
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="font-display text-2xl font-bold">Leads ({rows.length})</h1><a href="/api/admin/export" className="btn btn-ghost !py-2">Export CSV</a></div>
      <form className="flex flex-wrap gap-3"><input name="q" defaultValue={q} placeholder="Search name, email, company" className="field max-w-xs" aria-label="Search leads" />
        <select name="status" defaultValue={status ?? ""} className="field max-w-[200px]" aria-label="Filter by status"><option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}</select>
        <button className="btn btn-primary !py-2">Filter</button></form>
      <div className="overflow-x-auto rounded-2xl border border-line">
        <table className="w-full min-w-[760px] text-left text-sm"><thead className="bg-surface2 text-xs uppercase tracking-wider text-muted"><tr>{["Date", "Name", "Service", "Status", "Priority"].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
          <tbody>{rows.length === 0 ? <tr><td colSpan={5} className="p-6 text-center text-muted">No enquiries match.</td></tr> : rows.map((r) => (
            <tr key={r.id} className="border-t border-line hover:bg-accent/5"><td className="p-3 text-muted">{r.createdAt.toLocaleDateString("en-IN")}</td><td className="p-3"><Link href={`/admin/leads/${r.id}`} className="font-medium hover:text-accent">{r.name}</Link><div className="text-xs text-muted">{r.email}</div></td><td className="p-3">{r.service}</td><td className="p-3">{r.status.replace("_", " ")}</td><td className={`p-3 font-semibold ${tone[r.priority]}`}>{r.priority}</td></tr>))}</tbody></table>
      </div>
    </div>
  );
}
