import Link from "next/link";
import Image from "next/image";
import { redirect } from "next/navigation";
import { LayoutDashboard, Inbox, Layers, Briefcase, FileText, Tag, Settings, ImageIcon, LogOut } from "lucide-react";
import { getSession } from "@/lib/auth";
import { ThemeToggle } from "@/components/ThemeToggle";

const links = [
  ["/admin", "Dashboard", LayoutDashboard], ["/admin/leads", "Leads", Inbox], ["/admin/services", "Services", Layers],
  ["/admin/portfolio", "Portfolio", Briefcase], ["/admin/blog", "Blog", FileText], ["/admin/pricing", "Pricing", Tag],
  ["/admin/media", "Media", ImageIcon], ["/admin/settings", "Settings", Settings],
] as const;

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const s = await getSession();
  if (!s) redirect("/admin/login");
  return (
    <div className="min-h-screen md:flex">
      <aside className="border-b border-line bg-surface md:min-h-screen md:w-60 md:border-b-0 md:border-r">
        <div className="flex items-center gap-3 p-4"><Image src="/brand/av-logo.png" alt="AV" width={36} height={35} className="rounded-lg" /><div className="text-sm font-bold leading-tight">Admin<span className="block text-xs font-normal text-muted">{s.role === "SUPER_ADMIN" ? "Super Admin" : "Editor"}</span></div></div>
        <nav className="flex gap-1 overflow-x-auto px-2 pb-3 md:flex-col md:overflow-visible" aria-label="Admin">
          {links.map(([h, l, Icon]) => <Link key={h} href={h} className="flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm text-soft hover:bg-accent/10 hover:text-accent"><Icon size={16} />{l}</Link>)}
        </nav>
      </aside>
      <div className="flex-1">
        <header className="flex items-center justify-between border-b border-line px-6 py-3"><p className="text-sm text-muted">Signed in as {s.email}</p>
          <div className="flex items-center gap-3"><ThemeToggle /><form action="/api/admin/logout" method="post"><button className="btn btn-ghost !py-2"><LogOut size={16} />Sign out</button></form></div>
        </header>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
