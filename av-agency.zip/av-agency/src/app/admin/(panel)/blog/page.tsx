import Link from "next/link";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata = { title: "Blog" };

export default async function AdminBlog() {
  const rows = await getDb().blogPost.findMany({ include: { category: true }, orderBy: { updatedAt: "desc" } });
  return (<div className="space-y-5"><div className="flex items-center justify-between"><h1 className="font-display text-2xl font-bold">Blog posts</h1><Link href="/admin/blog/new" className="btn btn-primary !py-2">New post</Link></div>
    <div className="overflow-x-auto rounded-2xl border border-line"><table className="w-full min-w-[600px] text-left text-sm"><thead className="bg-surface2 text-xs uppercase tracking-wider text-muted"><tr><th className="p-3">Title</th><th className="p-3">Category</th><th className="p-3">Status</th><th className="p-3">Updated</th></tr></thead>
      <tbody>{rows.map((r) => <tr key={r.id} className="border-t border-line"><td className="p-3"><Link href={`/admin/blog/${r.id}`} className="font-medium hover:text-accent">{r.title}</Link></td><td className="p-3">{r.category.name}</td><td className="p-3">{r.published ? "Published" : "Draft"}</td><td className="p-3 text-muted">{r.updatedAt.toLocaleDateString("en-IN")}</td></tr>)}</tbody></table></div></div>);
}
