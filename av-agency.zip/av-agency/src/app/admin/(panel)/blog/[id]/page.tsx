import { notFound } from "next/navigation";
import Link from "next/link";
import { getDb } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { deletePost, savePost } from "../../../actions";

export const dynamic = "force-dynamic";

export default async function EditPost({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const db = getDb();
  const [cats, post, s] = await Promise.all([db.blogCategory.findMany({ orderBy: { name: "asc" } }), id === "new" ? null : db.blogPost.findUnique({ where: { id } }), getSession()]);
  if (id !== "new" && !post) notFound();
  return (
    <div className="max-w-3xl space-y-5"><Link href="/admin/blog" className="text-sm text-accent">← All posts</Link>
      <h1 className="font-display text-2xl font-bold">{post ? "Edit post" : "New post"}</h1>
      <form action={savePost} className="card !transform-none space-y-4 p-5">{post && <input type="hidden" name="id" value={post.id} />}
        <div><label className="mb-1 block text-sm" htmlFor="title">Title</label><input id="title" name="title" required defaultValue={post?.title} className="field" /></div>
        <div className="grid gap-4 sm:grid-cols-2"><div><label className="mb-1 block text-sm" htmlFor="slug">Slug</label><input id="slug" name="slug" defaultValue={post?.slug} className="field" /></div>
          <div><label className="mb-1 block text-sm" htmlFor="categoryId">Category</label><select id="categoryId" name="categoryId" defaultValue={post?.categoryId} required className="field">{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div></div>
        <div><label className="mb-1 block text-sm" htmlFor="excerpt">Excerpt</label><textarea id="excerpt" name="excerpt" rows={2} required defaultValue={post?.excerpt} className="field" /></div>
        <div><label className="mb-1 block text-sm" htmlFor="content">Content (## headings, - bullets, blank line between paragraphs)</label><textarea id="content" name="content" rows={14} required defaultValue={post?.content} className="field font-mono" /></div>
        <div className="grid gap-4 sm:grid-cols-2"><div><label className="mb-1 block text-sm" htmlFor="seoTitle">SEO title</label><input id="seoTitle" name="seoTitle" defaultValue={post?.seoTitle ?? ""} className="field" /></div><div><label className="mb-1 block text-sm" htmlFor="featuredImageId">Featured image asset ID</label><input id="featuredImageId" name="featuredImageId" defaultValue={post?.featuredImageId ?? ""} className="field" /></div></div>
        <div><label className="mb-1 block text-sm" htmlFor="metaDescription">Meta description</label><textarea id="metaDescription" name="metaDescription" rows={2} defaultValue={post?.metaDescription ?? ""} className="field" /></div>
        <div className="flex items-center gap-4"><select name="status" defaultValue={post?.published ? "published" : "draft"} className="field max-w-[180px]" aria-label="Status"><option value="draft">Draft</option><option value="published">Published</option></select><button className="btn btn-primary">Save post</button></div></form>
      {post && s?.role === "SUPER_ADMIN" && <form action={deletePost}><input type="hidden" name="id" value={post.id} /><button className="text-sm text-red-500 underline">Delete this post</button></form>}
    </div>);
}
