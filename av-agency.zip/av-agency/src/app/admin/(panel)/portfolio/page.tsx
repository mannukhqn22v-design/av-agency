import { getDb } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { deleteProject, saveProject } from "../../actions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Portfolio" };
type P = Awaited<ReturnType<ReturnType<typeof getDb>["portfolioProject"]["findMany"]>>[number];

function Form({ p }: { p?: P }) {
  const f = (label: string, name: string, v?: string, area = false) => (<div><label className="mb-1 block text-sm">{label}</label>{area ? <textarea name={name} rows={3} defaultValue={v} className="field" /> : <input name={name} defaultValue={v} className="field" />}</div>);
  return (
    <form action={saveProject} className="space-y-3">{p && <input type="hidden" name="id" value={p.id} />}
      <div className="grid gap-3 sm:grid-cols-3">{f("Title", "title", p?.title)}{f("Slug", "slug", p?.slug)}{f("Category", "category", p?.category)}</div>
      {f("Overview", "overview", p?.overview, true)}{f("Objective", "objective", p?.objective, true)}{f("Tools & methodology", "methodology", p?.methodology, true)}
      {f("Work completed (one per line)", "workDone", p?.workDone.join("\n"), true)}{f("Sample deliverables (one per line)", "deliverables", p?.deliverables.join("\n"), true)}{f("Lessons & recommendations", "lessons", p?.lessons, true)}{f("Image asset ID (from Media)", "imageId", p?.imageId ?? "")}
      <div className="flex flex-wrap gap-6 text-sm"><label className="flex items-center gap-2"><input type="checkbox" name="isPractice" defaultChecked={p?.isPractice ?? true} /> Practice / sample work (shows PRACTICE label)</label><label className="flex items-center gap-2"><input type="checkbox" name="published" defaultChecked={p?.published} /> Published</label></div>
      <button className="btn btn-primary !py-2">{p ? "Save" : "Add project"}</button></form>);
}

export default async function Portfolio() {
  const [rows, s] = await Promise.all([getDb().portfolioProject.findMany({ orderBy: { createdAt: "asc" } }), getSession()]);
  return (<div className="space-y-6"><h1 className="font-display text-2xl font-bold">Portfolio</h1>
    {rows.map((p) => (<details key={p.id} className="card !transform-none p-5"><summary className="flex cursor-pointer justify-between font-semibold">{p.title}<span className="text-xs font-normal text-muted">{p.published ? "Published" : "Unpublished"} · {p.isPractice ? "Practice" : "Sample"}</span></summary><div className="mt-4"><Form p={p} />{s?.role === "SUPER_ADMIN" && <form action={deleteProject} className="mt-3"><input type="hidden" name="id" value={p.id} /><button className="text-sm text-red-500 underline">Delete project</button></form>}</div></details>))}
    <details className="card !transform-none p-5"><summary className="cursor-pointer font-semibold text-accent">+ Add project</summary><div className="mt-4"><Form /></div></details></div>);
}
