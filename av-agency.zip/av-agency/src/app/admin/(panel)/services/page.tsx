import { getDb } from "@/lib/db";
import { deleteService, saveService } from "../../actions";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const metadata = { title: "Services" };

function Form({ s }: { s?: Awaited<ReturnType<ReturnType<typeof getDb>["service"]["findMany"]>>[number] }) {
  return (
    <form action={saveService} className="space-y-3">
      {s && <input type="hidden" name="id" value={s.id} />}
      <div className="grid gap-3 sm:grid-cols-2"><div><label className="mb-1 block text-sm">Title</label><input name="title" defaultValue={s?.title} required className="field" /></div><div><label className="mb-1 block text-sm">Slug</label><input name="slug" defaultValue={s?.slug} className="field" /></div></div>
      <div><label className="mb-1 block text-sm">Summary</label><input name="summary" defaultValue={s?.summary} required className="field" /></div>
      <div><label className="mb-1 block text-sm">Description</label><textarea name="description" rows={3} defaultValue={s?.description} className="field" /></div>
      <div><label className="mb-1 block text-sm">Features (one per line)</label><textarea name="features" rows={3} defaultValue={s?.features.join("\n")} className="field" /></div>
      <div className="grid gap-3 sm:grid-cols-3"><div><label className="mb-1 block text-sm">Image asset ID (from Media)</label><input name="imageId" defaultValue={s?.imageId ?? ""} className="field" /></div><div><label className="mb-1 block text-sm">Sort order</label><input name="sortOrder" type="number" defaultValue={s?.sortOrder ?? 0} className="field" /></div><label className="mt-6 flex items-center gap-2 text-sm"><input type="checkbox" name="enabled" defaultChecked={s?.enabled ?? true} /> Enabled</label></div>
      <button className="btn btn-primary !py-2">{s ? "Save" : "Add service"}</button>
    </form>
  );
}

export default async function Services() {
  const [rows, sess] = await Promise.all([getDb().service.findMany({ orderBy: { sortOrder: "asc" } }), getSession()]);
  return (
    <div className="space-y-6"><h1 className="font-display text-2xl font-bold">Services</h1>
      {rows.map((s) => (
        <details key={s.id} className="card !transform-none p-5"><summary className="flex cursor-pointer items-center justify-between font-semibold">{s.title}<span className="text-xs font-normal text-muted">{s.enabled ? "Enabled" : "Disabled"}</span></summary>
          <div className="mt-4"><Form s={s} />{sess?.role === "SUPER_ADMIN" && <form action={deleteService} className="mt-3"><input type="hidden" name="id" value={s.id} /><button className="text-sm text-red-500 underline">Delete service</button></form>}</div></details>))}
      <details className="card !transform-none p-5"><summary className="cursor-pointer font-semibold text-accent">+ Add new service</summary><div className="mt-4"><Form /></div></details>
    </div>
  );
}
