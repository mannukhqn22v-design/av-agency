import Link from "next/link";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata = { title: "Dashboard" };

export default async function Dashboard() {
  const db = getDb();
  const [total, fresh, byService, recent, posts, drafts, logs] = await Promise.all([
    db.contactEnquiry.count(), db.contactEnquiry.count({ where: { status: "NEW" } }),
    db.contactEnquiry.groupBy({ by: ["service"], _count: { _all: true }, orderBy: { _count: { service: "desc" } } }),
    db.contactEnquiry.findMany({ orderBy: { createdAt: "desc" }, take: 5 }),
    db.blogPost.count({ where: { published: true } }), db.blogPost.count({ where: { published: false } }),
    db.activityLog.findMany({ orderBy: { createdAt: "desc" }, take: 8 }),
  ]);
  const stats = [["Total enquiries", total], ["New enquiries", fresh], ["Published posts", posts], ["Draft posts", drafts]];
  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl font-bold">Dashboard</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{stats.map(([l, v]) => <div key={l} className="card !transform-none p-5"><p className="text-sm text-muted">{l}</p><p className="mt-1 font-display text-3xl font-bold">{v}</p></div>)}</div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card !transform-none p-5"><h2 className="mb-3 font-semibold">Service-wise enquiries</h2>
          {byService.length === 0 ? <p className="text-sm text-muted">No enquiries yet.</p> : <ul className="space-y-2 text-sm">{byService.map((b) => <li key={b.service} className="flex justify-between"><span>{b.service}</span><span className="font-semibold">{b._count._all}</span></li>)}</ul>}
        </section>
        <section className="card !transform-none p-5"><h2 className="mb-3 font-semibold">Recent contact requests</h2>
          {recent.length === 0 ? <p className="text-sm text-muted">Nothing yet.</p> : <ul className="space-y-2 text-sm">{recent.map((r) => <li key={r.id}><Link href={`/admin/leads/${r.id}`} className="flex justify-between hover:text-accent"><span>{r.name} · {r.service}</span><span className="text-muted">{r.createdAt.toLocaleDateString("en-IN")}</span></Link></li>)}</ul>}
        </section>
      </div>
      <section className="card !transform-none p-5"><h2 className="mb-3 font-semibold">Recent activity</h2>
        {logs.length === 0 ? <p className="text-sm text-muted">No activity.</p> : <ul className="space-y-1 text-sm text-muted">{logs.map((l) => <li key={l.id}>{l.createdAt.toLocaleString("en-IN")} · {l.action}</li>)}</ul>}
      </section>
    </div>
  );
}
