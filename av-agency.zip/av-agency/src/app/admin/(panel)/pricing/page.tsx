import { getDb } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { deletePlan, savePlan } from "../../actions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Pricing" };
type P = Awaited<ReturnType<ReturnType<typeof getDb>["pricingPlan"]["findMany"]>>[number];

function Form({ p }: { p?: P }) {
  return (<form action={savePlan} className="space-y-3">{p && <input type="hidden" name="id" value={p.id} />}
    <div className="grid gap-3 sm:grid-cols-4"><div className="sm:col-span-2"><label className="mb-1 block text-sm">Name</label><input name="name" defaultValue={p?.name} required className="field" /></div><div><label className="mb-1 block text-sm">Price INR</label><input name="priceInr" type="number" min={0} defaultValue={p?.priceInr ?? ""} className="field" /></div><div><label className="mb-1 block text-sm">Price USD</label><input name="priceUsd" type="number" min={0} defaultValue={p?.priceUsd ?? ""} className="field" /></div></div>
    <div className="grid gap-3 sm:grid-cols-3"><div><label className="mb-1 block text-sm">Price note</label><input name="priceNote" defaultValue={p?.priceNote ?? "onwards"} className="field" /></div><div><label className="mb-1 block text-sm">Slug</label><input name="slug" defaultValue={p?.slug} className="field" /></div><div><label className="mb-1 block text-sm">Sort order</label><input name="sortOrder" type="number" defaultValue={p?.sortOrder ?? 0} className="field" /></div></div>
    <div><label className="mb-1 block text-sm">Features (one per line)</label><textarea name="features" rows={4} defaultValue={p?.features.join("\n")} className="field" /></div>
    <div className="flex gap-6 text-sm"><label className="flex items-center gap-2"><input type="checkbox" name="custom" defaultChecked={p?.custom} /> Custom quotation (hides price)</label><label className="flex items-center gap-2"><input type="checkbox" name="enabled" defaultChecked={p?.enabled ?? true} /> Visible</label></div>
    <button className="btn btn-primary !py-2">{p ? "Save" : "Add plan"}</button></form>);
}

export default async function Pricing() {
  const [rows, s] = await Promise.all([getDb().pricingPlan.findMany({ orderBy: { sortOrder: "asc" } }), getSession()]);
  return (<div className="space-y-6"><h1 className="font-display text-2xl font-bold">Pricing plans</h1>
    {rows.map((p) => <details key={p.id} className="card !transform-none p-5"><summary className="flex cursor-pointer justify-between font-semibold">{p.name}<span className="text-xs font-normal text-muted">{p.custom ? "Custom" : `₹${p.priceInr ?? "-"}`}</span></summary><div className="mt-4"><Form p={p} />{s?.role === "SUPER_ADMIN" && <form action={deletePlan} className="mt-3"><input type="hidden" name="id" value={p.id} /><button className="text-sm text-red-500 underline">Delete plan</button></form>}</div></details>)}
    <details className="card !transform-none p-5"><summary className="cursor-pointer font-semibold text-accent">+ Add plan</summary><div className="mt-4"><Form /></div></details></div>);
}
