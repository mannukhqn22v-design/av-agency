"use client";
import { useState } from "react";

export default function Media() {
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  async function up(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const r = await fetch("/api/admin/upload", { method: "POST", body: new FormData(e.currentTarget) });
    const d = await r.json();
    setMsg(r.ok ? { ok: true, text: `Uploaded. Asset ID: ${d.id}  ·  URL: ${d.url}` } : { ok: false, text: d.error });
  }
  return (<div className="max-w-xl space-y-5"><h1 className="font-display text-2xl font-bold">Media upload</h1>
    <form onSubmit={up} className="card !transform-none space-y-4 p-5"><div><label className="mb-1 block text-sm" htmlFor="file">Image (PNG, JPG, WebP, max 4 MB)</label><input id="file" type="file" name="file" accept="image/png,image/jpeg,image/webp" required className="field" /></div><div><label className="mb-1 block text-sm" htmlFor="alt">Alt text</label><input id="alt" name="alt" className="field" /></div><button className="btn btn-primary">Upload</button></form>
    {msg && <p role="status" className={`rounded-xl p-3 text-sm ${msg.ok ? "bg-emerald-500/10 text-emerald-500" : "bg-red-500/10 text-red-500"}`}>{msg.text}</p>}
    <p className="text-xs text-muted">Use the Asset ID in the Image fields of Services, Portfolio and Blog.</p></div>);
}
