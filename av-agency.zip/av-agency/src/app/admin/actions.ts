"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { getSession, type Session } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { slugify } from "@/lib/validators";

async function must(superOnly = false): Promise<Session> {
  const s = await getSession();
  if (!s) redirect("/admin/login");
  if (superOnly && s.role !== "SUPER_ADMIN") throw new Error("Forbidden: Super Admin only");
  return s;
}
const log = (s: Session, action: string, entity: string, entityId?: string) => getDb().activityLog.create({ data: { action, entity, entityId, userId: s.uid } });
const lines = (v: FormDataEntryValue | null) => String(v ?? "").split("\n").map((x) => x.trim()).filter(Boolean);
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const optStr = (fd: FormData, k: string) => str(fd, k) || null;
const optInt = (fd: FormData, k: string) => { const v = str(fd, k); return v === "" ? null : Math.max(0, parseInt(v, 10) || 0); };
const refresh = (...p: string[]) => { p.forEach((x) => revalidatePath(x)); revalidatePath("/", "layout"); };

// ---- Leads ----
const leadSchema = z.object({ status: z.enum(["NEW", "CONTACTED", "QUALIFIED", "PROPOSAL_SENT", "CONVERTED", "CLOSED"]), priority: z.enum(["LOW", "MEDIUM", "HIGH"]), notes: z.string().max(5000) });
export async function updateEnquiry(fd: FormData) {
  const s = await must();
  const id = str(fd, "id");
  const d = leadSchema.parse({ status: str(fd, "status"), priority: str(fd, "priority"), notes: str(fd, "notes") });
  await getDb().contactEnquiry.update({ where: { id }, data: { ...d, notes: d.notes || null } });
  await log(s, "enquiry.update", "ContactEnquiry", id);
  refresh("/admin/leads", "/admin");
}
export async function deleteEnquiry(fd: FormData) {
  const s = await must(true);
  const id = str(fd, "id");
  await getDb().contactEnquiry.delete({ where: { id } });
  await log(s, "enquiry.delete", "ContactEnquiry", id);
  refresh("/admin/leads", "/admin");
  redirect("/admin/leads");
}

// ---- Services ----
export async function saveService(fd: FormData) {
  const s = await must();
  const db = getDb();
  const id = str(fd, "id");
  const title = z.string().min(2).max(120).parse(str(fd, "title"));
  const cat = await db.serviceCategory.upsert({ where: { slug: "digital-marketing" }, update: {}, create: { slug: "digital-marketing", name: "Digital Marketing" } });
  const data = { title, slug: slugify(str(fd, "slug") || title), summary: str(fd, "summary"), description: str(fd, "description") || str(fd, "summary"), features: lines(fd.get("features")), imageId: optStr(fd, "imageId"), enabled: fd.get("enabled") === "on", sortOrder: optInt(fd, "sortOrder") ?? 0 };
  const row = id ? await db.service.update({ where: { id }, data }) : await db.service.create({ data: { ...data, categoryId: cat.id } });
  await log(s, id ? "service.update" : "service.create", "Service", row.id);
  refresh("/admin/services");
}
export async function deleteService(fd: FormData) {
  const s = await must(true); const id = str(fd, "id");
  await getDb().service.delete({ where: { id } }); await log(s, "service.delete", "Service", id); refresh("/admin/services");
}

// ---- Portfolio ----
export async function saveProject(fd: FormData) {
  const s = await must();
  const id = str(fd, "id");
  const title = z.string().min(2).max(160).parse(str(fd, "title"));
  const data = { title, slug: slugify(str(fd, "slug") || title), category: str(fd, "category") || "SEO", isPractice: fd.get("isPractice") === "on", overview: str(fd, "overview"), objective: str(fd, "objective"), methodology: str(fd, "methodology"), workDone: lines(fd.get("workDone")), deliverables: lines(fd.get("deliverables")), lessons: str(fd, "lessons"), imageId: optStr(fd, "imageId"), published: fd.get("published") === "on" };
  const row = id ? await getDb().portfolioProject.update({ where: { id }, data }) : await getDb().portfolioProject.create({ data });
  await log(s, id ? "project.update" : "project.create", "PortfolioProject", row.id);
  refresh("/admin/portfolio", "/portfolio");
}
export async function deleteProject(fd: FormData) {
  const s = await must(true); const id = str(fd, "id");
  await getDb().portfolioProject.delete({ where: { id } }); await log(s, "project.delete", "PortfolioProject", id); refresh("/admin/portfolio", "/portfolio");
}

// ---- Blog ----
export async function savePost(fd: FormData) {
  const s = await must();
  const db = getDb();
  const id = str(fd, "id");
  const title = z.string().min(3).max(200).parse(str(fd, "title"));
  const content = str(fd, "content");
  const published = fd.get("status") === "published";
  const existing = id ? await db.blogPost.findUnique({ where: { id } }) : null;
  const data = {
    title, slug: slugify(str(fd, "slug") || title), excerpt: str(fd, "excerpt"), content,
    seoTitle: optStr(fd, "seoTitle"), metaDescription: optStr(fd, "metaDescription"), featuredImageId: optStr(fd, "featuredImageId"),
    categoryId: str(fd, "categoryId"), published, publishedAt: published ? existing?.publishedAt ?? new Date() : null,
    readingMinutes: Math.max(1, Math.round(content.split(/\s+/).filter(Boolean).length / 200)),
  };
  const row = id ? await db.blogPost.update({ where: { id }, data }) : await db.blogPost.create({ data: { ...data, authorId: s.uid } });
  await log(s, id ? "post.update" : "post.create", "BlogPost", row.id);
  refresh("/admin/blog", "/blog");
  redirect("/admin/blog");
}
export async function deletePost(fd: FormData) {
  const s = await must(true); const id = str(fd, "id");
  await getDb().blogPost.delete({ where: { id } }); await log(s, "post.delete", "BlogPost", id); refresh("/admin/blog", "/blog"); redirect("/admin/blog");
}

// ---- Pricing ----
export async function savePlan(fd: FormData) {
  const s = await must();
  const id = str(fd, "id");
  const name = z.string().min(2).max(100).parse(str(fd, "name"));
  const custom = fd.get("custom") === "on";
  const data = { name, slug: slugify(str(fd, "slug") || name), priceInr: custom ? null : optInt(fd, "priceInr"), priceUsd: custom ? null : optInt(fd, "priceUsd"), priceNote: str(fd, "priceNote") || "onwards", features: lines(fd.get("features")), custom, enabled: fd.get("enabled") === "on", sortOrder: optInt(fd, "sortOrder") ?? 0 };
  const row = id ? await getDb().pricingPlan.update({ where: { id }, data }) : await getDb().pricingPlan.create({ data });
  await log(s, id ? "plan.update" : "plan.create", "PricingPlan", row.id);
  refresh("/admin/pricing", "/pricing");
}
export async function deletePlan(fd: FormData) {
  const s = await must(true); const id = str(fd, "id");
  await getDb().pricingPlan.delete({ where: { id } }); await log(s, "plan.delete", "PricingPlan", id); refresh("/admin/pricing", "/pricing");
}

// ---- Settings ----
export async function saveSettings(fd: FormData) {
  const s = await must();
  const email = z.string().email().parse(str(fd, "contactEmail"));
  const wa = str(fd, "whatsappNumber").replace(/\D/g, "");
  const url = (k: string) => { const v = str(fd, k); return v && /^https?:\/\//i.test(v) ? v : null; };
  const data = { agencyName: str(fd, "agencyName") || "Aakash Verma Digital Agency", tagline: str(fd, "tagline"), contactEmail: email, whatsappNumber: wa || null, location: str(fd, "location"), linkedinUrl: url("linkedinUrl"), instagramUrl: url("instagramUrl"), facebookUrl: url("facebookUrl"), gaId: optStr(fd, "gaId"), gtmId: optStr(fd, "gtmId"), metaPixelId: optStr(fd, "metaPixelId") };
  await getDb().siteSettings.upsert({ where: { id: "singleton" }, update: data, create: { id: "singleton", ...data } });
  await log(s, "settings.update", "SiteSettings", "singleton");
  refresh("/admin/settings", "/contact");
}
