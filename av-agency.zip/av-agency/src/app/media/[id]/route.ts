import { readFile } from "fs/promises";
import path from "path";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) return new Response("Not found", { status: 404 });
  const a = await getDb().mediaAsset.findUnique({ where: { id } });
  if (!a) return new Response("Not found", { status: 404 });
  try {
    const buf = await readFile(path.join(/*turbopackIgnore: true*/ path.resolve(/*turbopackIgnore: true*/ process.env.UPLOAD_DIR || "./uploads"), path.basename(a.path)));
    return new Response(new Uint8Array(buf), { headers: { "Content-Type": a.mimeType, "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" } });
  } catch { return new Response("Not found", { status: 404 }); }
}
