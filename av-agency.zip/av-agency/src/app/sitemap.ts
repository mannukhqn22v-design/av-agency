import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";
import { SERVICE_PAGES } from "@/lib/services-content";
import { getPosts } from "@/lib/data";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const posts = await getPosts();
  const staticRoutes = ["", "/about", "/portfolio", "/pricing", "/blog", "/contact", "/privacy"];
  return [
    ...staticRoutes.map((r) => ({ url: SITE.url + r, changeFrequency: "monthly" as const, priority: r === "" ? 1 : 0.7 })),
    ...Object.keys(SERVICE_PAGES).map((s) => ({ url: `${SITE.url}/services/${s}`, changeFrequency: "monthly" as const, priority: 0.9 })),
    ...posts.map((p) => ({ url: `${SITE.url}/blog/${p.slug}`, lastModified: p.publishedAt, priority: 0.6 })),
  ];
}
