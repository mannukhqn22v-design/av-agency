import { NextResponse } from "next/server";
import { dbConfigured, getDb } from "@/lib/db";
import { enquirySchema } from "@/lib/validators";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { sendEnquiryNotification } from "@/lib/mail";

export const runtime = "nodejs";

export async function POST(req: Request) {
  // same-origin check (CSRF protection for this public JSON endpoint)
  const origin = req.headers.get("origin");
  const host = req.headers.get("host");
  if (origin && host && new URL(origin).host !== host) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const ip = clientIp(req);
  const rl = rateLimit(`enquiry:${ip}`, 5, 10 * 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: `Too many submissions. Try again in ${Math.ceil(rl.retryAfter / 60)} minute(s).` }, { status: 429, headers: { "Retry-After": String(rl.retryAfter) } });

  let body: unknown;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid request" }, { status: 400 }); }

  const parsed = enquirySchema.safeParse(body);
  if (!parsed.success) {
    const fields: Record<string, string> = {};
    for (const i of parsed.error.issues) fields[String(i.path[0])] ||= i.message;
    return NextResponse.json({ error: "Please check the highlighted fields.", fields }, { status: 400 });
  }
  const d = parsed.data;

  // spam: honeypot filled or submitted faster than a human could
  if (d.hp || (d.startedAt && Date.now() - d.startedAt < 2500)) {
    return NextResponse.json({ message: "Thanks! We will be in touch." }); // silently drop bots
  }

  if (!dbConfigured) return NextResponse.json({ error: "Enquiries are temporarily unavailable. Please email us directly." }, { status: 503 });

  try {
    const db = getDb();
    // duplicate prevention: same email + same message within 15 minutes
    const since = new Date(Date.now() - 15 * 60 * 1000);
    const dup = await db.contactEnquiry.findFirst({ where: { email: d.email.toLowerCase(), message: d.message, createdAt: { gte: since } }, select: { id: true } });
    if (dup) return NextResponse.json({ message: "We already received this enquiry and will reply soon." });

    const saved = await db.contactEnquiry.create({
      data: { name: d.name, email: d.email.toLowerCase(), company: d.company || null, websiteUrl: d.websiteUrl || null, service: d.service, budget: d.budget || null, message: d.message, contactMethod: d.contactMethod },
    });

    let emailed = false;
    try { emailed = (await sendEnquiryNotification(d)).sent; } catch (e) { console.error("[mail] failed:", (e as Error).message); }
    await db.activityLog.create({ data: { action: emailed ? "enquiry.received+emailed" : "enquiry.received", entity: "ContactEnquiry", entityId: saved.id } });

    return NextResponse.json({ message: "Thank you! Your enquiry has been received and we will reply within 1-2 business days." });
  } catch (e) {
    console.error("[enquiry] save failed:", (e as Error).message);
    return NextResponse.json({ error: "We could not save your enquiry. Please try again or email us directly." }, { status: 500 });
  }
}
