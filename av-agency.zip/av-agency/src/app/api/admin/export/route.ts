import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getDb } from "@/lib/db";

const cell = (v: unknown) => {
  let s = v == null ? "" : v instanceof Date ? v.toISOString() : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise CSV/Excel formula injection
  return `"${s.replace(/"/g, '""')}"`;
};

export async function GET() {
  if (!(await getSession())) return new NextResponse("Unauthorized", { status: 401 });
  const rows = await getDb().contactEnquiry.findMany({ orderBy: { createdAt: "desc" } });
  const head = ["Date", "Name", "Email", "Company", "Website", "Service", "Budget", "Contact method", "Status", "Priority", "Message", "Notes"];
  const lines = [head.map(cell).join(",")].concat(rows.map((r) => [r.createdAt, r.name, r.email, r.company, r.websiteUrl, r.service, r.budget, r.contactMethod, r.status, r.priority, r.message, r.notes].map(cell).join(",")));
  return new NextResponse("﻿" + lines.join("\r\n"), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="enquiries-${new Date().toISOString().slice(0, 10)}.csv"` } });
}
