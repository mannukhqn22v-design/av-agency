import { NextResponse } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { getSession } from "@/lib/auth";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";
const MAX = 4 * 1024 * 1024;
// verify real file type from magic bytes, never trust the client-provided MIME
function sniff(b: Buffer): { mime: string; ext: string } | null {
  if (b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: "image/png", ext: "png" };
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (b.length > 12 && b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP") return { mime: "image/webp", ext: "webp" };
  return null;
}

export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const origin = req.headers.get("origin"); const host = req.headers.get("host");
  if (origin && host && new URL(origin).host !== host) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const fd = await req.formData();
  const file = fd.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "No file" }, { status: 400 });
  if (file.size > MAX) return NextResponse.json({ error: "File too large (max 4 MB)" }, { status: 413 });
  const buf = Buffer.from(await file.arrayBuffer());
  const t = sniff(buf);
  if (!t) return NextResponse.json({ error: "Only PNG, JPG or WebP images are allowed" }, { status: 415 });
  const dir = path.resolve(/*turbopackIgnore: true*/ process.env.UPLOAD_DIR || "./uploads");
  await mkdir(dir, { recursive: true });
  const id = randomUUID();
  const stored = `${id}.${t.ext}`;
  await writeFile(path.join(/*turbopackIgnore: true*/ dir, stored), buf);
  const alt = String(fd.get("alt") || "").slice(0, 200);
  const a = await getDb().mediaAsset.create({ data: { id, filename: file.name.slice(0, 120), mimeType: t.mime, sizeBytes: buf.length, path: stored, alt } });
  await getDb().activityLog.create({ data: { action: "media.upload", entity: "MediaAsset", entityId: a.id, userId: s.uid } });
  return NextResponse.json({ id: a.id, url: `/media/${a.id}` });
}
