import { NextResponse } from "next/server";
import { z } from "zod";
import { createSession, login } from "@/lib/auth";
import { dbConfigured, getDb } from "@/lib/db";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";
const schema = z.object({ email: z.string().email().max(160), password: z.string().min(1).max(200) });

export async function POST(req: Request) {
  const origin = req.headers.get("origin"); const host = req.headers.get("host");
  if (origin && host && new URL(origin).host !== host) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const ip = clientIp(req);
  const rl = rateLimit(`login:${ip}`, 8, 15 * 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "Too many attempts. Try again later." }, { status: 429, headers: { "Retry-After": String(rl.retryAfter) } });
  if (!dbConfigured) return NextResponse.json({ error: "Database is not configured." }, { status: 503 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid email and password." }, { status: 400 });
  try {
    const s = await login(parsed.data.email, parsed.data.password);
    if (!s) return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    await createSession(s);
    await getDb().activityLog.create({ data: { action: "admin.login", entity: "AdminUser", entityId: s.uid, userId: s.uid } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("[login]", (e as Error).message);
    return NextResponse.json({ error: "Login is unavailable. Check server configuration." }, { status: 500 });
  }
}
