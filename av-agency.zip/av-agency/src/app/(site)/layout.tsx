import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Loader } from "@/components/Loader";

export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Loader />
      <Navbar />
      <main id="main">{children}</main>
      <Footer />
    </>
  );
}
