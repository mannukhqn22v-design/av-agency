import type { Metadata } from "next";
import { PageHero, Section, Badge } from "@/components/ui";
import { getProjects } from "@/lib/data";
import { Check } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = { title: "Portfolio: Practice & Sample Projects", description: "Practice projects and concept work showing our SEO, ads and analytics methodology. Clearly labelled, never presented as paid client work.", alternates: { canonical: "/portfolio" } };

export default async function Portfolio() {
  const projects = await getProjects();
  return (
    <>
      <PageHero title="Portfolio & case studies" intro="Every item below is a practice project or concept sample, labelled as such. We do not publish invented client results." crumbs={[{ name: "Portfolio", href: "/portfolio" }]} />
      <Section>
        <div className="space-y-8">
          {projects.map((p) => (
            <article key={p.slug} id={p.slug} className="card !transform-none scroll-mt-28 p-6 md:p-8">
              <div className="flex flex-wrap items-center gap-3"><Badge tone="warn">{p.isPractice ? "PRACTICE PROJECT" : "SAMPLE / CONCEPT WORK"}</Badge><Badge tone="muted">{p.category}</Badge></div>
              <h2 className="mt-3 font-display text-2xl font-bold">{p.title}</h2>
              <p className="mt-2 text-muted">{p.overview}</p>
              <div className="mt-6 grid gap-6 text-sm md:grid-cols-2">
                <div><h3 className="mb-1 font-semibold">Objective</h3><p className="text-muted">{p.objective}</p></div>
                <div><h3 className="mb-1 font-semibold">Tools and methodology</h3><p className="text-muted">{p.methodology}</p></div>
                <div><h3 className="mb-1 font-semibold">Work completed</h3><ul className="space-y-1">{p.workDone.map((w) => <li key={w} className="flex gap-2 text-muted"><Check size={16} className="mt-0.5 shrink-0 text-accent" />{w}</li>)}</ul></div>
                <div><h3 className="mb-1 font-semibold">Sample deliverables</h3><ul className="space-y-1">{p.deliverables.map((w) => <li key={w} className="flex gap-2 text-muted"><Check size={16} className="mt-0.5 shrink-0 text-accent" />{w}</li>)}</ul></div>
                <div className="md:col-span-2"><h3 className="mb-1 font-semibold">Lessons and recommendations</h3><p className="text-muted">{p.lessons}</p></div>
              </div>
            </article>
          ))}
        </div>
        <p className="mt-10 text-center text-sm text-muted">Want real results documented here one day? <Link href="/contact" className="text-accent underline">Become our first case study.</Link></p>
      </Section>
    </>
  );
}
