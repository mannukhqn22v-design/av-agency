import Link from "next/link";
import { ArrowRight, BarChart3, Database, LineChart, Megaphone, Search, Target, ShieldCheck, Gauge, Eye, Handshake } from "lucide-react";
import { Hero3D } from "@/components/3d/Hero3D";
import { Reveal } from "@/components/Reveal";
import { Section, Faq, Badge } from "@/components/ui";
import { AnimatedBars } from "@/components/Visuals";
import { HOME_FAQ } from "@/lib/defaults";
import { getPosts, getProjects } from "@/lib/data";
import { SITE } from "@/lib/site";

const services = [
  { icon: Search, title: "SEO", text: "Audits, keyword research, on-page and technical SEO with transparent reporting.", href: "/services/seo" },
  { icon: Target, title: "Google Ads", text: "Search, display and remarketing campaigns built around conversion tracking.", href: "/services/google-ads" },
  { icon: Megaphone, title: "Meta Ads", text: "Facebook and Instagram campaigns for leads, traffic and awareness.", href: "/services/meta-ads" },
  { icon: Database, title: "B2B Lead Generation", text: "Prospect research, enrichment and CRM data hygiene.", href: "/services/b2b-lead-generation" },
  { icon: BarChart3, title: "Analytics & Reporting", text: "GA4, Search Console and Excel MIS reports that drive decisions.", href: "/services/analytics-reporting" },
  { icon: LineChart, title: "Strategy", text: "Roadmaps that connect marketing activity to business goals.", href: "/contact" },
];
const why = [
  { icon: Eye, t: "Radical transparency", d: "Clear scope, documented work and honest reporting. No inflated claims." },
  { icon: Gauge, t: "Data-first decisions", d: "Hands-on data operations background: accurate, structured and audit-friendly." },
  { icon: ShieldCheck, t: "No ranking guarantees", d: "We never promise rankings, leads or ROAS. We promise careful work." },
  { icon: Handshake, t: "Founder-led", d: "You work directly with Aakash Verma, not a layered account team." },
];
const process = ["Discover", "Plan", "Execute", "Measure", "Improve"];
const capabilities = ["SEO Audits", "Keyword Research", "Google Ads", "Meta Ads", "GA4 & GSC", "B2B Lead Research", "CRM Data Hygiene", "Excel MIS Reporting"];

export default async function Home() {
  const [projects, posts] = await Promise.all([getProjects(), getPosts()]);
  return (
    <>
      <section className="relative overflow-hidden pt-28">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-6 px-5 pb-10 lg:grid-cols-2">
          <div>
            <Badge>New Delhi · Founder-led agency</Badge>
            <h1 className="mt-5 font-display text-5xl font-bold leading-[1.05] md:text-7xl">
              <span className="text-gradient">Data-Driven Marketing.</span> Measurable Digital Growth.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted">
              We help businesses strengthen their online visibility, generate qualified leads and make smarter marketing decisions through SEO, paid advertising and data-driven strategies.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/contact" className="btn btn-primary">Get a Free Consultation <ArrowRight size={18} /></Link>
              <Link href="#services" className="btn btn-ghost">Explore Our Services</Link>
            </div>
          </div>
          <Hero3D />
        </div>
      </section>

      <section aria-label="Capabilities" className="border-y border-line bg-surface/40 py-6">
        <ul className="mx-auto flex max-w-7xl flex-wrap justify-center gap-x-8 gap-y-3 px-5 text-sm font-medium text-muted">
          {capabilities.map((c) => <li key={c} className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-accent" />{c}</li>)}
        </ul>
      </section>

      <Section kicker="About" title="A founder-led agency built on data discipline" intro="Aakash Verma brings years of B2B data operations experience together with training in SEO, paid media and analytics.">
        <div className="grid gap-8 md:grid-cols-2">
          <Reveal><p className="leading-relaxed text-soft">Our approach is simple: understand the business, measure what matters, act on evidence and report honestly. We are a small agency by design, so every project gets direct attention.</p><Link href="/about" className="mt-5 inline-flex items-center gap-2 font-semibold text-accent">Read our story <ArrowRight size={16} /></Link></Reveal>
          <Reveal delay={0.1}><AnimatedBars label="Sample: organic visits by month" data={[{ label: "Jan", value: 30 }, { label: "Feb", value: 38 }, { label: "Mar", value: 45 }, { label: "Apr", value: 52 }, { label: "May", value: 61 }, { label: "Jun", value: 74 }]} /></Reveal>
        </div>
      </Section>

      <Section id="services" kicker="Services" title="Core services">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.05}>
              <Link href={s.href} className="card group block h-full p-6">
                <s.icon className="mb-4 text-accent" size={28} />
                <h3 className="font-display text-xl font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted">{s.text}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-accent">Learn more <ArrowRight size={14} className="transition group-hover:translate-x-1" /></span>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section kicker="Why choose us" title="Marketing you can actually verify">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {why.map((w, i) => (
            <Reveal key={w.t} delay={i * 0.06}><div className="card h-full p-6"><w.icon className="mb-3 text-accent2" size={26} /><h3 className="font-semibold">{w.t}</h3><p className="mt-2 text-sm text-muted">{w.d}</p></div></Reveal>
          ))}
        </div>
      </Section>

      <Section kicker="Process" title="How we work">
        <ol className="grid gap-4 md:grid-cols-5">
          {process.map((p, i) => (
            <Reveal key={p} delay={i * 0.07}><li className="card h-full p-5"><span className="font-display text-3xl font-bold text-gradient">0{i + 1}</span><h3 className="mt-2 font-semibold">{p}</h3></li></Reveal>
          ))}
        </ol>
      </Section>

      <Section kicker="Portfolio" title="Featured projects" intro="These are practice and concept projects, clearly labelled. We never present them as paid client work.">
        <div className="grid gap-5 md:grid-cols-3">
          {projects.slice(0, 3).map((p) => (
            <Link key={p.slug} href={`/portfolio#${p.slug}`} className="card block p-6">
              <Badge tone="warn">{p.isPractice ? "Practice project" : "Sample / concept work"}</Badge>
              <h3 className="mt-3 font-display text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-sm text-muted">{p.overview}</p>
            </Link>
          ))}
        </div>
      </Section>

      <Section kicker="Insights" title="From the blog">
        <div className="grid gap-5 md:grid-cols-3">
          {posts.slice(0, 3).map((p) => (
            <Link key={p.slug} href={`/blog/${p.slug}`} className="card block p-6">
              <Badge tone="muted">{p.category}</Badge>
              <h3 className="mt-3 font-display text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-sm text-muted">{p.excerpt}</p>
              <p className="mt-3 text-xs text-muted">{p.readingMinutes} min read</p>
            </Link>
          ))}
        </div>
      </Section>
      {/* Testimonials: intentionally omitted until genuine, permissioned testimonials exist. */}

      <Section kicker="FAQ" title="Questions, answered honestly"><Faq items={HOME_FAQ} schema /></Section>

      <section className="px-5 pb-20">
        <div className="relative mx-auto max-w-5xl overflow-hidden rounded-3xl border border-line bg-surface p-10 text-center md:p-16">
          <div className="pointer-events-none absolute -top-20 left-1/2 h-60 w-96 -translate-x-1/2 rounded-full bg-accent/25 blur-[100px]" />
          <h2 className="relative font-display text-3xl font-bold md:text-5xl">Ready to grow with data on your side?</h2>
          <p className="relative mx-auto mt-4 max-w-xl text-muted">Tell us about your business. We will suggest a practical starting point, no obligation.</p>
          <div className="relative mt-7 flex flex-wrap justify-center gap-3">
            <Link href="/contact" className="btn btn-primary">Get a Free Consultation</Link>
            <a href={`mailto:${SITE.email}`} className="btn btn-ghost">Email us</a>
          </div>
        </div>
      </section>
    </>
  );
}
