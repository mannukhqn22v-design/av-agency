import type { Metadata } from "next";
import { PageHero, Section, Badge } from "@/components/ui";
import { Reveal } from "@/components/Reveal";
import Link from "next/link";

export const metadata: Metadata = { title: "About Aakash Verma Digital Agency", description: "Founder-led digital marketing agency in New Delhi, built on data operations experience and training in SEO, paid media and analytics.", alternates: { canonical: "/about" } };

const values = [
  ["Honesty first", "We never inflate results or invent credentials."],
  ["Evidence over opinion", "Recommendations come from data, not hunches."],
  ["Clarity", "Plain-language reports your whole team can follow."],
  ["Accuracy", "Careful, quality-checked work, a habit built in data operations."],
];
const skills = ["SEO & keyword research", "Google Ads & Meta Ads planning", "GA4 & Search Console", "B2B lead research", "Salesforce CRM data hygiene", "Excel MIS reporting", "LinkedIn Sales Navigator", "Hunter.io & Snov.io"];

export default function About() {
  return (
    <>
      <PageHero title="About the agency" intro="A small, founder-led agency combining disciplined data work with modern digital marketing." crumbs={[{ name: "About", href: "/about" }]} />
      <Section kicker="Founder" title="Aakash Verma">
        <div className="grid gap-10 md:grid-cols-2">
          <Reveal><p className="leading-relaxed text-soft">Aakash is a digital marketer based in New Delhi with 4+ years of hands-on experience in data operations, including B2B lead research, Salesforce CRM data hygiene and Excel MIS reporting. He completed professional training in Digital Marketing with AI at DuCAT India, covering SEO, SEM, Google Ads, Meta Ads, social media, email marketing and analytics.</p></Reveal>
          <Reveal delay={0.1}>
            <div className="card !transform-none p-6">
              <h3 className="mb-3 font-semibold">Experience, training and practice, kept distinct</h3>
              <ul className="space-y-3 text-sm text-muted">
                <li><Badge>Professional experience</Badge><p className="mt-1">Data operations roles: Process Associate at SunTec India and eDataIndia (lead research, CRM data hygiene, MIS reporting).</p></li>
                <li><Badge tone="muted">Training</Badge><p className="mt-1">Digital Marketing with AI at DuCAT India; Simplilearn certificates in SEO, Excel and data analytics.</p></li>
                <li><Badge tone="warn">Practice projects</Badge><p className="mt-1">WanderVista Travels and sample campaign plans, clearly labelled as practice work, not paid clients.</p></li>
              </ul>
            </div>
          </Reveal>
        </div>
      </Section>
      <Section kicker="Philosophy" title="Our approach">
        <div className="grid gap-5 md:grid-cols-2">
          <div className="card !transform-none p-6"><h3 className="font-semibold">Mission</h3><p className="mt-2 text-sm text-muted">Help businesses make confident marketing decisions through accurate data and honest execution.</p></div>
          <div className="card !transform-none p-6"><h3 className="font-semibold">Vision</h3><p className="mt-2 text-sm text-muted">Become a trusted, transparent growth partner for businesses of every size.</p></div>
        </div>
        <p className="mt-6 max-w-3xl text-muted">Methodology: Discover the business and audience, analyse the data, plan priorities, execute, then measure and improve on a regular cycle.</p>
      </Section>
      <Section kicker="Values" title="What guides the work">
        <div className="grid gap-5 md:grid-cols-4">{values.map(([t, d]) => <div key={t} className="card h-full p-6"><h3 className="font-semibold">{t}</h3><p className="mt-2 text-sm text-muted">{d}</p></div>)}</div>
      </Section>
      <Section kicker="Expertise" title="Skills and tools">
        <ul className="flex flex-wrap gap-3">{skills.map((s) => <li key={s} className="rounded-full border border-line bg-surface px-4 py-2 text-sm">{s}</li>)}</ul>
        <Link href="/contact" className="btn btn-primary mt-10">Work with us</Link>
      </Section>
    </>
  );
}
