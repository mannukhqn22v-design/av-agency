import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Link from "next/link";
import { Breadcrumbs, JsonLd, Badge, renderMarkdown } from "@/components/ui";
import { getPosts } from "@/lib/data";
import { SITE } from "@/lib/site";

export async function generateMetadata({ params }: PageProps<"/blog/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const p = (await getPosts()).find((x) => x.slug === slug);
  if (!p) return {};
  return { title: p.seoTitle || p.title, description: p.metaDescription || p.excerpt, alternates: { canonical: `/blog/${slug}` }, openGraph: { type: "article", title: p.title, description: p.excerpt, publishedTime: p.publishedAt } };
}

export default async function Post({ params }: PageProps<"/blog/[slug]">) {
  const { slug } = await params;
  const posts = await getPosts();
  const p = posts.find((x) => x.slug === slug);
  if (!p) notFound();
  const related = posts.filter((x) => x.slug !== slug && x.category === p.category).concat(posts.filter((x) => x.slug !== slug && x.category !== p.category)).slice(0, 3);
  const url = `${SITE.url}/blog/${slug}`;
  const share = (base: string) => base + encodeURIComponent(url);
  return (
    <article className="mx-auto max-w-3xl px-5 pb-20 pt-36">
      <Breadcrumbs items={[{ name: "Blog", href: "/blog" }, { name: p.title, href: `/blog/${slug}` }]} />
      <Badge>{p.category}</Badge>
      <h1 className="mt-4 font-display text-4xl font-bold md:text-5xl">{p.title}</h1>
      <p className="mt-3 text-sm text-muted">By {SITE.founder} · {new Date(p.publishedAt).toLocaleDateString("en-IN", { dateStyle: "long" })} · {p.readingMinutes} min read</p>
      <div className="prose-av mt-10">{renderMarkdown(p.content)}</div>
      <div className="mt-10 flex flex-wrap items-center gap-3 border-t border-line pt-6 text-sm">
        <span className="text-muted">Share:</span>
        <a className="btn btn-ghost !py-2" href={share("https://www.linkedin.com/sharing/share-offsite/?url=")} target="_blank" rel="noopener noreferrer">LinkedIn</a>
        <a className="btn btn-ghost !py-2" href={share("https://twitter.com/intent/tweet?url=")} target="_blank" rel="noopener noreferrer">X</a>
        <a className="btn btn-ghost !py-2" href={share("https://wa.me/?text=")} target="_blank" rel="noopener noreferrer">WhatsApp</a>
      </div>
      <section className="mt-14"><h2 className="mb-4 font-display text-2xl font-bold">Related posts</h2>
        <div className="grid gap-4 sm:grid-cols-2">{related.map((r) => <Link key={r.slug} href={`/blog/${r.slug}`} className="card block p-5"><p className="font-semibold">{r.title}</p><p className="mt-1 text-xs text-muted">{r.readingMinutes} min read</p></Link>)}</div>
      </section>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "BlogPosting", headline: p.title, description: p.excerpt, datePublished: p.publishedAt, author: { "@type": "Person", name: SITE.founder }, publisher: { "@type": "Organization", name: SITE.name }, mainEntityOfPage: url }} />
    </article>
  );
}
