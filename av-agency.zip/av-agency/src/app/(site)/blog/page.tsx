import type { Metadata } from "next";
import Link from "next/link";
import { PageHero, Section, Badge } from "@/components/ui";
import { getPosts } from "@/lib/data";
import { BLOG_CATEGORIES } from "@/lib/defaults";

export const metadata: Metadata = { title: "Digital Marketing Insights Blog", description: "Practical articles on SEO, keyword research, Google Ads, Meta Ads, B2B lead generation and analytics.", alternates: { canonical: "/blog" } };

export default async function Blog({ searchParams }: PageProps<"/blog">) {
  const sp = await searchParams;
  const cat = typeof sp.category === "string" ? sp.category : "";
  const q = typeof sp.q === "string" ? sp.q.trim().toLowerCase() : "";
  const posts = (await getPosts()).filter((p) => (!cat || p.category === cat) && (!q || (p.title + p.excerpt).toLowerCase().includes(q)));
  return (
    <>
      <PageHero title="Digital marketing insights" intro="Practical, no-hype articles from our own work." crumbs={[{ name: "Blog", href: "/blog" }]} />
      <Section>
        <form action="/blog" className="mb-6 flex flex-col gap-3 sm:flex-row">
          <label htmlFor="q" className="sr-only">Search articles</label>
          <input id="q" name="q" defaultValue={q} placeholder="Search articles…" className="field flex-1" />
          {cat && <input type="hidden" name="category" value={cat} />}
          <button className="btn btn-primary">Search</button>
        </form>
        <div className="mb-8 flex flex-wrap gap-2" role="list" aria-label="Categories">
          <Link href="/blog" className={`rounded-full border px-4 py-1.5 text-sm ${!cat ? "border-accent text-accent" : "border-line text-muted"}`}>All</Link>
          {BLOG_CATEGORIES.map((c) => <Link key={c} href={`/blog?category=${encodeURIComponent(c)}`} className={`rounded-full border px-4 py-1.5 text-sm ${cat === c ? "border-accent text-accent" : "border-line text-muted hover:text-fg"}`}>{c}</Link>)}
        </div>
        {posts.length === 0 ? <p className="text-muted">No articles found.</p> : (
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {posts.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="card block p-6">
                <Badge tone="muted">{p.category}</Badge>
                <h2 className="mt-3 font-display text-xl font-semibold">{p.title}</h2>
                <p className="mt-2 text-sm text-muted">{p.excerpt}</p>
                <p className="mt-4 text-xs text-muted">{new Date(p.publishedAt).toLocaleDateString("en-IN", { dateStyle: "medium" })} · {p.readingMinutes} min read</p>
              </Link>
            ))}
          </div>
        )}
      </Section>
    </>
  );
}
