import type { Metadata } from "next";
import { PageHero } from "@/components/ui";
import { SITE } from "@/lib/site";

export const metadata: Metadata = { title: "Privacy Policy", alternates: { canonical: "/privacy" } };

export default function Privacy() {
  return (
    <>
      <PageHero title="Privacy Policy" crumbs={[{ name: "Privacy", href: "/privacy" }]} />
      <div className="prose-av mx-auto max-w-3xl px-5 pb-20">
        <p>This is a starter policy. Have it reviewed against your legal obligations before launch.</p>
        <h2>What we collect</h2><p>Details you submit through our enquiry form (name, email, company, website, requirements). Analytics and advertising cookies are used only if you accept them.</p>
        <h2>How we use it</h2><p>To respond to your enquiry and improve our services. We do not sell personal data.</p>
        <h2>Contact</h2><p>Questions: {SITE.email}</p>
      </div>
    </>
  );
}
