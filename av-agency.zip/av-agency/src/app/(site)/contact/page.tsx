import type { Metadata } from "next";
import { Mail, MapPin, MessageCircle } from "lucide-react";
import { PageHero, Section } from "@/components/ui";
import { ContactForm } from "@/components/ContactForm";
import { getSettings } from "@/lib/data";
import { SERVICE_OPTIONS } from "@/lib/site";

export const metadata: Metadata = { title: "Contact", description: "Request a free consultation for SEO, Google Ads, Meta Ads, B2B lead generation or analytics reporting.", alternates: { canonical: "/contact" } };

export default async function Contact({ searchParams }: PageProps<"/contact">) {
  const sp = await searchParams;
  const s = await getSettings();
  const wa = (s.whatsappNumber || "").replace(/\D/g, "");
  const wanted = typeof sp.service === "string" ? sp.service : "";
  const defaultService = SERVICE_OPTIONS.find((o) => o.toLowerCase().startsWith(wanted.toLowerCase()) && wanted) || "";
  return (
    <>
      <PageHero title="Let's talk about your growth" intro="Share a few details and we will reply with a practical next step." crumbs={[{ name: "Contact", href: "/contact" }]} />
      <Section>
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2"><ContactForm defaultService={defaultService} /></div>
          <aside className="space-y-4">
            <div className="card !transform-none p-6">
              <h2 className="mb-4 font-semibold">Contact details</h2>
              <ul className="space-y-3 text-sm">
                <li className="flex gap-2"><Mail className="text-accent" size={18} /><a href={`mailto:${s.contactEmail}`} className="hover:text-accent">{s.contactEmail}</a></li>
                <li className="flex gap-2"><MapPin className="text-accent" size={18} />{s.location}</li>
              </ul>
              <div className="mt-5 flex flex-col gap-2">
                <a href={`mailto:${s.contactEmail}?subject=Consultation%20request`} className="btn btn-ghost">Email enquiry</a>
                {wa ? <a href={`https://wa.me/${wa}?text=Hi%2C%20I%27d%20like%20to%20discuss%20a%20project`} target="_blank" rel="noopener noreferrer" className="btn btn-ghost"><MessageCircle size={18} /> WhatsApp enquiry</a> : <p className="text-xs text-muted">WhatsApp enquiry is not enabled yet.</p>}
              </div>
            </div>
          </aside>
        </div>
      </Section>
    </>
  );
}
