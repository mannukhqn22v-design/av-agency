import Link from "next/link";
export default function NotFound() {
  return (<div className="grid min-h-[70vh] place-items-center px-5 pt-24 text-center"><div><p className="font-display text-7xl font-bold text-gradient">404</p><h1 className="mt-2 text-2xl font-bold">Page not found</h1><Link href="/" className="btn btn-primary mt-6">Back to home</Link></div></div>);
}
