import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Link from "next/link";
import { Check } from "lucide-react";
import { SERVICE_PAGES } from "@/lib/services-content";
import { PageHero, Section, Faq, Badge, JsonLd } from "@/components/ui";
import { AnimatedBars, CampaignFlow, LeadTable, LineChart, Counter, SampleTag } from "@/components/Visuals";
import { SITE } from "@/lib/site";

export function generateStaticParams() {
  return Object.keys(SERVICE_PAGES).map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: PageProps<"/services/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const p = SERVICE_PAGES[slug];
  if (!p) return {};
  return { title: p.title, description: p.metaDescription, alternates: { canonical: `/services/${slug}` }, openGraph: { title: p.title, description: p.metaDescription, url: `/services/${slug}` } };
}

export default async function ServicePage({ params }: PageProps<"/services/[slug]">) {
  const { slug } = await params;
  const p = SERVICE_PAGES[slug];
  if (!p) notFound();
  const quote = (t: string) => `/contact?service=${encodeURIComponent(p.title.replace(" Services", ""))}&topic=${encodeURIComponent(t)}`;

  return (
    <>
      <PageHero title={p.heading} intro={p.intro} crumbs={[{ name: "Services", href: "/#services" }, { name: p.title, href: `/services/${p.slug}` }]}>
        <p className="mt-5 max-w-3xl rounded-xl border border-line bg-surface/60 p-4 text-sm text-muted">{p.disclaimer}</p>
        <div className="mt-6 flex gap-3"><Link href={quote("general")} className="btn btn-primary">Get a Quote</Link><a href="#services-list" className="btn btn-ghost">See what&apos;s included</a></div>
      </PageHero>

      {slug === "meta-ads" && <Section title="Campaign workflow"><CampaignFlow /></Section>}
      {slug === "b2b-lead-generation" && <Section title="What the deliverable looks like"><LeadTable /></Section>}
      {slug === "analytics-reporting" && (
        <Section title="Sample dashboard" intro="Illustrative data only. These are not real website statistics.">
          <div className="grid gap-5 md:grid-cols-3">
            {[["Organic sessions", 1280], ["Engagement rate %", 62], ["Conversions", 48]].map(([l, v]) => (
              <div key={l} className="card !transform-none p-6"><div className="mb-2 flex justify-between"><p className="text-sm text-muted">{l}</p><SampleTag /></div><p className="font-display text-4xl font-bold text-gradient"><Counter to={v as number} /></p></div>
            ))}
          </div>
          <div className="mt-5 grid gap-5 md:grid-cols-2">
            <LineChart label="Sample: weekly organic sessions" points={[40, 46, 44, 55, 61, 58, 72, 80]} />
            <AnimatedBars label="Sample: conversions by channel" data={[{ label: "Organic", value: 48 }, { label: "Paid", value: 30 }, { label: "Social", value: 18 }, { label: "Direct", value: 24 }]} />
          </div>
        </Section>
      )}

      <Section title="How we work" kicker="Process">
        <ol className="grid gap-4 md:grid-cols-5">
          {p.process.map((s, i) => (
            <li key={s.title} className="card !transform-none p-5"><span className="font-display text-2xl font-bold text-gradient">0{i + 1}</span><h3 className="mt-1 font-semibold">{s.title}</h3><p className="mt-1 text-sm text-muted">{s.text}</p></li>
          ))}
        </ol>
      </Section>

      <Section id="services-list" title={`${p.title}: what's included`} kicker={`${p.items.length} services`}>
        <div className="space-y-3">
          {p.items.map((it) => (
            <details key={it.slug} id={it.slug} className="card group !transform-none p-5 open:border-accent/50">
              <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-3">
                <span className="flex items-center gap-3 font-semibold">{it.title}{it.status === "on-consultation" && <Badge tone="warn">On consultation</Badge>}</span>
                <span className="text-accent transition group-open:rotate-45">+</span>
              </summary>
              <div className="mt-4 grid gap-6 text-sm md:grid-cols-3">
                <div className="md:col-span-3 text-muted">{it.overview}</div>
                {([["What's included", it.includes], ["Business benefits", it.benefits], ["Deliverables", it.deliverables]] as const).map(([h, list]) => (
                  <div key={h}><h4 className="mb-2 font-semibold">{h}</h4><ul className="space-y-1.5">{list.map((l) => <li key={l} className="flex gap-2 text-muted"><Check size={16} className="mt-0.5 shrink-0 text-accent" />{l}</li>)}</ul></div>
                ))}
                {it.faq && <div className="md:col-span-3 rounded-xl bg-surface2 p-4"><p className="font-semibold">{it.faq.q}</p><p className="mt-1 text-muted">{it.faq.a}</p></div>}
                <div className="md:col-span-3"><Link href={quote(it.title)} className="btn btn-primary !py-2.5">Get a Quote for {it.title}</Link></div>
              </div>
            </details>
          ))}
        </div>
      </Section>

      <Section title="Frequently asked questions" kicker="FAQ"><Faq items={p.faqs} schema /></Section>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "Service", name: p.title, provider: { "@type": "Organization", name: SITE.name, url: SITE.url }, areaServed: "IN", description: p.metaDescription }} />
    </>
  );
}
