import type { Metadata } from "next";
import Link from "next/link";
import { Check } from "lucide-react";
import { PageHero, Section, Faq } from "@/components/ui";
import { getPlans } from "@/lib/data";

export const metadata: Metadata = { title: "Pricing", description: "Indicative pricing for SEO, B2B lead research and analytics reporting. Google Ads and Meta Ads are quoted after consultation.", alternates: { canonical: "/pricing" } };

const inr = (n: number) => "₹" + n.toLocaleString("en-IN");

export default async function Pricing() {
  const plans = await getPlans();
  const all = Array.from(new Set(plans.flatMap((p) => p.features)));
  return (
    <>
      <PageHero title="Simple, honest pricing" intro="Indicative starting prices in INR (USD approximate). Final pricing depends on project scope, complexity and deliverables." crumbs={[{ name: "Pricing", href: "/pricing" }]} />
      <Section>
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {plans.map((p) => (
            <div key={p.slug} className="card flex h-full flex-col p-6">
              <h2 className="font-display text-lg font-semibold">{p.name}</h2>
              <p className="mt-3 font-display text-3xl font-bold text-gradient">{p.custom || p.priceInr == null ? "Custom" : inr(p.priceInr)}</p>
              <p className="text-sm text-muted">{p.priceNote}{p.priceUsd ? ` · ≈ $${p.priceUsd} USD` : ""}</p>
              <ul className="my-5 flex-1 space-y-2 text-sm">{p.features.map((f) => <li key={f} className="flex gap-2 text-muted"><Check size={16} className="mt-0.5 shrink-0 text-accent" />{f}</li>)}</ul>
              <Link href={`/contact?plan=${p.slug}`} className="btn btn-primary">{p.custom ? "Request a quote" : "Get started"}</Link>
            </div>
          ))}
        </div>
        <p className="mt-6 text-center text-sm text-muted">Final pricing depends on project scope, complexity and deliverables. Ad spend is paid separately to the ad platform.</p>
      </Section>
      <Section title="Package comparison">
        <div className="overflow-x-auto rounded-2xl border border-line">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="bg-surface2 text-xs uppercase tracking-wider text-muted"><tr><th className="p-4">Included</th>{plans.map((p) => <th key={p.slug} className="p-4">{p.name}</th>)}</tr></thead>
            <tbody>{all.map((f) => (<tr key={f} className="border-t border-line"><td className="p-4">{f}</td>{plans.map((p) => <td key={p.slug} className="p-4">{p.features.includes(f) ? <Check size={18} className="text-accent" aria-label="Included" /> : <span className="text-muted" aria-label="Not included">-</span>}</td>)}</tr>))}</tbody>
          </table>
        </div>
      </Section>
      <Section title="Pricing FAQ"><Faq items={[{ q: "Is GST included?", a: "Quotes are exclusive of applicable taxes unless stated otherwise." }, { q: "Are there long contracts?", a: "No long lock-ins are required for the starter packages. Details are agreed in your proposal." }]} /></Section>
    </>
  );
}
