import type { Metadata, Viewport } from "next";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Analytics } from "@/components/Analytics";
import { JsonLd } from "@/components/ui";
import { SITE } from "@/lib/site";
import { getSettings } from "@/lib/data";

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: `${SITE.name} | ${SITE.tagline}`, template: `%s | ${SITE.name}` },
  description: SITE.description,
  applicationName: SITE.name,
  authors: [{ name: SITE.founder }],
  openGraph: { type: "website", siteName: SITE.name, locale: "en_IN", images: [{ url: "/brand/av-logo.png", width: 863, height: 843, alt: "AV monogram" }] },
  twitter: { card: "summary", title: SITE.name, description: SITE.description },
  robots: { index: true, follow: true },
};
export const viewport: Viewport = { themeColor: "#080a0d", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const s = await getSettings();
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[200] focus:rounded-lg focus:bg-accent focus:px-4 focus:py-2 focus:text-white">Skip to content</a>
          {children}
          <Analytics ids={{ ga: s.gaId, gtm: s.gtmId, pixel: s.metaPixelId }} />
        </ThemeProvider>
        <JsonLd data={{ "@context": "https://schema.org", "@type": "Organization", name: SITE.name, url: SITE.url, logo: `${SITE.url}/brand/av-logo.png`, email: SITE.email, founder: { "@type": "Person", name: SITE.founder }, address: { "@type": "PostalAddress", addressLocality: "New Delhi", addressCountry: "IN" } }} />
      </body>
    </html>
  );
}
