import nodemailer from "nodemailer";

export const mailConfigured = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

export async function sendEnquiryNotification(e: { name: string; email: string; company?: string | null; websiteUrl?: string | null; service: string; budget?: string | null; message: string; contactMethod: string }) {
  if (!mailConfigured) return { sent: false, reason: "SMTP not configured" };
  const t = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT || 587) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  const to = process.env.ENQUIRY_TO_EMAIL || process.env.NEXT_PUBLIC_CONTACT_EMAIL || "aakashverma852787@gmail.com";
  await t.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to,
    replyTo: e.email,
    subject: `New enquiry: ${e.service} from ${e.name}`.replace(/[\r\n]/g, " "),
    html: `<h2>New website enquiry</h2>
<p><b>Name:</b> ${esc(e.name)}<br><b>Email:</b> ${esc(e.email)}<br><b>Company:</b> ${esc(e.company || "-")}<br><b>Website:</b> ${esc(e.websiteUrl || "-")}<br><b>Service:</b> ${esc(e.service)}<br><b>Budget:</b> ${esc(e.budget || "-")}<br><b>Preferred contact:</b> ${esc(e.contactMethod)}</p>
<p><b>Requirements:</b><br>${esc(e.message).replace(/\n/g, "<br>")}</p>`,
  });
  return { sent: true };
}
