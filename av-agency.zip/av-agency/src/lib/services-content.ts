export type ServiceItem = {
  slug: string;
  title: string;
  overview: string;
  includes: string[];
  benefits: string[];
  deliverables: string[];
  faq?: { q: string; a: string };
  status?: "offered" | "on-consultation";
};

export type ServicePageData = {
  slug: string;
  title: string;
  heading: string;
  intro: string;
  metaDescription: string;
  disclaimer: string;
  process: { title: string; text: string }[];
  items: ServiceItem[];
  faqs: { q: string; a: string }[];
};

const seoItems: ServiceItem[] = [
  { slug: "seo-audit", title: "SEO Audit", overview: "A structured review of your website's search health: crawlability, indexation, on-page elements, content and technical issues.", includes: ["Crawl and indexation review", "Title, meta and heading checks", "Content gap observations", "Priority-ranked issue list"], benefits: ["Clear picture of what is holding the site back", "A prioritised to-do list instead of guesswork"], deliverables: ["Audit report (PDF/Excel)", "Prioritised action sheet"], faq: { q: "How long does an audit take?", a: "Timelines depend on site size and complexity; we confirm the schedule after reviewing the scope." } },
  { slug: "seo-strategy", title: "SEO Strategy", overview: "A practical roadmap that connects business goals to keywords, content and technical priorities.", includes: ["Goal and audience mapping", "Keyword and content roadmap", "Quarterly priorities"], benefits: ["Focused effort on what matters", "Shared plan your team can follow"], deliverables: ["Strategy document", "Content and optimisation calendar"] },
  { slug: "keyword-research", title: "SEO Keyword Research", overview: "Research of the terms your customers use, grouped by intent and mapped to pages.", includes: ["Seed and long-tail discovery", "Intent classification", "Keyword-to-page mapping", "Difficulty and volume review"], benefits: ["Content aligned with real search demand", "Fewer overlapping pages"], deliverables: ["Keyword sheet in Excel", "Page mapping matrix"] },
  { slug: "competitor-analysis", title: "Competitor SEO Analysis", overview: "A comparison of how competing sites approach keywords, content and site structure.", includes: ["Competitor shortlist", "Keyword overlap and gaps", "Content structure comparison"], benefits: ["Spot opportunities competitors have missed", "Benchmark your current position"], deliverables: ["Competitor comparison sheet", "Opportunity summary"] },
  { slug: "on-page-seo", title: "On-Page SEO", overview: "Optimisation of titles, descriptions, headings, copy, images and internal elements for target keywords.", includes: ["Title and meta rewrites", "Heading and copy recommendations", "Image alt text", "URL recommendations"], benefits: ["Clearer relevance signals to search engines", "Better click-through potential"], deliverables: ["Page-by-page optimisation sheet"] },
  { slug: "technical-seo", title: "Technical SEO", overview: "Review and recommendations for crawlability, site architecture, indexation, redirects and structured data.", includes: ["Robots and sitemap review", "Canonical and redirect checks", "Site architecture review", "Error and status-code review"], benefits: ["Fewer crawl and indexing problems", "A healthier technical foundation"], deliverables: ["Technical issues log", "Fix recommendations for developers"] },
  { slug: "off-page-seo", title: "Off-Page SEO Strategy", overview: "A strategy for earning relevant, quality mentions and links, focused on sustainable practices.", includes: ["Backlink profile review", "Link opportunity research", "Outreach approach"], benefits: ["Safer long-term authority building"], deliverables: ["Off-page plan", "Opportunity list"] },
  { slug: "local-seo", title: "Local SEO", overview: "Optimisation for location-based searches including business profile and local signals.", includes: ["Google Business Profile review", "NAP consistency check", "Local keyword targeting"], benefits: ["Better visibility for nearby customers"], deliverables: ["Local SEO checklist and recommendations"] },
  { slug: "ecommerce-seo", title: "E-commerce SEO", overview: "Category, product page and faceted-navigation optimisation for online stores.", includes: ["Category and product page review", "Product copy guidance", "Faceted URL handling advice"], benefits: ["Stronger product discoverability"], deliverables: ["Store SEO recommendations"] },
  { slug: "content-seo", title: "Content SEO", overview: "Content planning and optimisation aligned to search intent and topical coverage.", includes: ["Topic cluster planning", "Content briefs", "Existing content refresh suggestions"], benefits: ["Content that answers what people search for"], deliverables: ["Content briefs", "Editorial calendar"] },
  { slug: "internal-linking", title: "Internal Linking Strategy", overview: "A plan for connecting related pages so users and crawlers can find important content.", includes: ["Orphan page detection", "Anchor text guidance", "Hub-and-spoke linking plan"], benefits: ["Better crawl paths and page discovery"], deliverables: ["Internal link map"] },
  { slug: "website-seo-optimization", title: "Website SEO Optimization", overview: "Combined on-page and technical improvements applied across the key pages of your site.", includes: ["Priority page optimisation", "Quick-win fixes", "Implementation guidance"], benefits: ["Practical improvements in a defined scope"], deliverables: ["Optimisation log"] },
  { slug: "seo-reporting", title: "SEO Reporting", overview: "Regular, readable reports on organic performance and the work completed.", includes: ["Organic traffic and query trends", "Work-done summary", "Next-step recommendations"], benefits: ["Transparent view of progress"], deliverables: ["Monthly report (PDF/Excel)"] },
  { slug: "search-console-analysis", title: "Google Search Console Analysis", overview: "Analysis of queries, pages, indexing and enhancements data from Search Console.", includes: ["Query and page performance", "Index coverage review", "Opportunity queries"], benefits: ["Insights from first-party search data"], deliverables: ["Search Console insights report"] },
  { slug: "ga4-reporting", title: "Google Analytics 4 Reporting", overview: "GA4 reporting focused on organic landing pages, engagement and conversions.", includes: ["Organic landing page analysis", "Event and conversion review", "Custom report setup guidance"], benefits: ["Understand what visitors do after they arrive"], deliverables: ["GA4 report and dashboard guidance"] },
  { slug: "core-web-vitals", title: "Core Web Vitals Recommendations", overview: "Review of LCP, INP and CLS with practical recommendations for your developer.", includes: ["Field and lab data review", "Image, script and layout recommendations"], benefits: ["A clearer path to a faster page experience"], deliverables: ["Performance recommendations list"] },
  { slug: "schema-markup", title: "Schema Markup Recommendations", overview: "Structured data recommendations matched to your page types and eligibility rules.", includes: ["Schema opportunity mapping", "JSON-LD examples", "Validation guidance"], benefits: ["Machine-readable context for your pages"], deliverables: ["Schema plan and sample JSON-LD"] },
  { slug: "seo-health-monitoring", title: "Website SEO Health Monitoring", overview: "Periodic checks that catch new technical or indexing issues early.", includes: ["Scheduled crawl checks", "Index and error monitoring", "Change alerts summary"], benefits: ["Early warning of problems"], deliverables: ["Periodic health summary"] },
];

export const SERVICE_PAGES: Record<string, ServicePageData> = {
  seo: {
    slug: "seo",
    title: "SEO Services",
    heading: "SEO Services built on research, not guesswork",
    intro: "From audits to technical fixes and reporting, we help your website become easier to find and easier to trust, using data from Search Console, Analytics and crawl tools.",
    metaDescription: "SEO services in New Delhi: audits, keyword research, on-page, technical, local and e-commerce SEO with transparent reporting. No ranking guarantees.",
    disclaimer: "SEO results depend on many factors, including competition, site history and search engine updates. We do not guarantee rankings or traffic.",
    process: [
      { title: "Discover", text: "Understand your business, audience and current visibility." },
      { title: "Analyse", text: "Audit the site, research keywords and review competitors." },
      { title: "Plan", text: "Prioritise actions into a clear roadmap." },
      { title: "Implement", text: "Apply or hand over optimisations with documentation." },
      { title: "Report", text: "Track progress and refine on a regular cycle." },
    ],
    items: seoItems,
    faqs: [
      { q: "Do you guarantee first-page rankings?", a: "No. Nobody can ethically guarantee rankings. We focus on sound practices and transparent reporting." },
      { q: "How long does SEO take to show results?", a: "It varies by competition and site condition. Many sites see movement over months, not days." },
      { q: "Can you work with my developer?", a: "Yes. Recommendations are written so a developer can implement them directly." },
    ],
  },
  "google-ads": {
    slug: "google-ads",
    title: "Google Ads Services",
    heading: "Google Ads campaigns structured for clarity and control",
    intro: "We plan, structure and report on Google Ads campaigns around your goals, with careful keyword planning and conversion tracking.",
    metaDescription: "Google Ads management: Search, Display, Performance Max, YouTube and remarketing with conversion tracking and clear reporting.",
    disclaimer: "We are not presenting any Google Partner status or certification. Results are not guaranteed; ad spend is paid directly to Google.",
    process: [
      { title: "Goals", text: "Define conversions, budget and target audience." },
      { title: "Research", text: "Keyword planning and audience research." },
      { title: "Structure", text: "Build campaigns, ad groups and ad copy." },
      { title: "Track", text: "Set up conversion tracking before launch." },
      { title: "Optimise", text: "Review search terms, bids and creatives regularly." },
    ],
    items: [
      { slug: "search-ads", title: "Google Search Ads", status: "offered", overview: "Text ads that appear when people search for your products or services.", includes: ["Keyword grouping", "Responsive search ads", "Negative keyword lists"], benefits: ["Reach people with active intent"], deliverables: ["Campaign plan", "Ad copy sheet"] },
      { slug: "display-ads", title: "Display Advertising", status: "on-consultation", overview: "Visual ads across the Google Display Network for awareness and remarketing.", includes: ["Audience selection", "Placement exclusions", "Creative guidelines"], benefits: ["Broader reach and brand recall"], deliverables: ["Display plan"] },
      { slug: "pmax", title: "Performance Max Campaigns", status: "on-consultation", overview: "Automated cross-channel campaigns driven by assets and conversion goals.", includes: ["Asset group planning", "Audience signals", "Feed review for stores"], benefits: ["Access to multiple Google inventories"], deliverables: ["PMax structure and asset list"] },
      { slug: "youtube-ads", title: "YouTube Advertising", status: "on-consultation", overview: "Video campaign planning for awareness and consideration.", includes: ["Audience planning", "Script and creative direction"], benefits: ["Video reach for brand stories"], deliverables: ["Video campaign plan"] },
      { slug: "remarketing", title: "Remarketing / Retargeting", status: "offered", overview: "Re-engage people who visited your site or interacted with your content.", includes: ["Audience list setup", "Frequency recommendations"], benefits: ["Reconnect with warm audiences"], deliverables: ["Remarketing setup"] },
      { slug: "keyword-planning", title: "Keyword Planning", status: "offered", overview: "Keyword research tailored to ad intent, match types and budget.", includes: ["Keyword Planner research", "Match type strategy"], benefits: ["More relevant traffic"], deliverables: ["Keyword plan sheet"] },
      { slug: "audience-research", title: "Audience Research", status: "offered", overview: "Understand who you want to reach and how they search.", includes: ["Persona drafting", "Segment ideas"], benefits: ["Sharper targeting"], deliverables: ["Audience brief"] },
      { slug: "campaign-structure", title: "Campaign Structure", status: "offered", overview: "Organising campaigns and ad groups so reporting and optimisation stay clean.", includes: ["Campaign and ad group architecture", "Naming conventions"], benefits: ["Easier management and analysis"], deliverables: ["Account structure document"] },
      { slug: "ad-copywriting", title: "Ad Copywriting", status: "offered", overview: "Clear, compliant ad copy aligned to the landing page and intent.", includes: ["Headline and description sets", "Extension copy"], benefits: ["Consistent messaging"], deliverables: ["Ad copy sheet"] },
      { slug: "conversion-tracking", title: "Conversion Tracking Setup", status: "offered", overview: "Tag and event setup so you can measure leads and sales.", includes: ["GA4 and Google Ads conversions", "Tag Manager configuration"], benefits: ["Measurable outcomes"], deliverables: ["Tracking implementation notes"] },
      { slug: "landing-page-recs", title: "Landing Page Recommendations", status: "offered", overview: "Suggestions to improve relevance and clarity of the page ads send people to.", includes: ["Message match review", "Form and CTA suggestions"], benefits: ["Better alignment of ad and page"], deliverables: ["Recommendation list"] },
      { slug: "campaign-optimization", title: "Campaign Optimization", status: "offered", overview: "Ongoing review of search terms, bids, budgets and creatives.", includes: ["Search terms review", "Bid strategy checks"], benefits: ["Spend directed to what works"], deliverables: ["Optimisation log"] },
      { slug: "budget-planning", title: "Budget Planning", status: "offered", overview: "Planning how to allocate spend across campaigns and months.", includes: ["Budget split proposals", "Scenario planning"], benefits: ["Realistic expectations"], deliverables: ["Budget plan"] },
      { slug: "performance-reporting", title: "Performance Reporting", status: "offered", overview: "Readable reports on spend, clicks, conversions and next steps.", includes: ["Monthly report", "KPI summary"], benefits: ["Transparent performance view"], deliverables: ["Report (PDF/Excel)"] },
    ],
    faqs: [
      { q: "Who pays for the ad spend?", a: "Ad spend is paid directly by you to Google. Management fees are separate." },
      { q: "Do you guarantee leads or ROAS?", a: "No. We plan and optimise carefully, but outcomes depend on market, offer, budget and landing page." },
      { q: "Which services are available now?", a: "Items marked 'On consultation' are scoped after a discussion to confirm fit and capability." },
    ],
  },
  "meta-ads": {
    slug: "meta-ads",
    title: "Meta Ads Services",
    heading: "Facebook and Instagram campaigns with a clear workflow",
    intro: "From audience research to creative planning and reporting, we plan Meta campaigns around your objective and measure what matters.",
    metaDescription: "Meta Ads services: Facebook and Instagram lead generation, traffic, engagement and retargeting campaigns with clear reporting.",
    disclaimer: "We do not guarantee leads, ROAS or sales. Ad spend is paid directly to Meta.",
    process: [
      { title: "Objective", text: "Choose the campaign goal." },
      { title: "Audience", text: "Research and build audiences." },
      { title: "Creative", text: "Plan ad creatives and copy." },
      { title: "Launch", text: "Configure tracking and go live." },
      { title: "Report", text: "Review results and refine." },
    ],
    items: [
      "Facebook Ads", "Instagram Ads", "Lead Generation Campaigns", "Traffic Campaigns", "Engagement Campaigns",
      "Awareness Campaigns", "Retargeting", "Custom Audience Strategy", "Audience Research", "Ad Creative Planning",
      "Ad Copywriting", "Instant Forms", "Campaign Reporting", "Conversion Tracking",
    ].map((t) => ({
      slug: t.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      title: t,
      overview: `${t}: planned around your objective, audience and budget with clear documentation.`,
      includes: ["Requirement discussion", "Setup or planning documentation", "Review and recommendations"],
      benefits: ["A structured, measurable approach"],
      deliverables: ["Plan or setup notes", "Reporting summary"],
    })),
    faqs: [
      { q: "Do you guarantee leads?", a: "No. Lead volume and quality depend on your offer, audience, creative and budget." },
      { q: "Do you need access to my ad account?", a: "We recommend partner or admin access so you retain ownership of your assets." },
    ],
  },
  "b2b-lead-generation": {
    slug: "b2b-lead-generation",
    title: "B2B Lead Generation",
    heading: "B2B lead research and data operations you can trust",
    intro: "Backed by hands-on experience in B2B data operations, we build accurate prospect lists and keep your CRM data clean.",
    metaDescription: "B2B lead research: company profiling, decision-maker research, prospect list building, email verification status, enrichment and CRM data cleaning.",
    disclaimer: "We follow applicable data-protection and platform terms. Sample data shown on this page is fictional and illustrative.",
    process: [
      { title: "ICP", text: "Define your ideal customer profile." },
      { title: "Research", text: "Find companies and decision-makers." },
      { title: "Verify", text: "Check and label contact data quality." },
      { title: "Enrich", text: "Add firmographic details." },
      { title: "Deliver", text: "Hand over in Excel or load to your CRM." },
    ],
    items: [
      "B2B Lead Research", "Company Profiling", "Decision-Maker Research", "LinkedIn Sales Navigator Research", "Prospect List Building",
      "Business Email Discovery", "Email Verification Status", "Data Enrichment", "CRM Data Cleaning", "Excel Lead Databases",
      "Contact Research", "Data Quality Assurance",
    ].map((t) => ({
      slug: t.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      title: t,
      overview: `${t} delivered with documented sources and a quality check pass.`,
      includes: ["Scope and criteria definition", "Research and compilation", "Quality check"],
      benefits: ["Cleaner data for your sales team"],
      deliverables: ["Excel/CSV file", "Short methodology note"],
    })),
    faqs: [
      { q: "Do you guarantee email deliverability?", a: "No. We report a verification status for each address, but deliverability can change over time." },
      { q: "What tools are used?", a: "LinkedIn Sales Navigator, Hunter.io, Snov.io, Salesforce and Excel, subject to each tool's terms." },
    ],
  },
  "analytics-reporting": {
    slug: "analytics-reporting",
    title: "Analytics & Reporting",
    heading: "Reports that turn marketing data into decisions",
    intro: "We turn GA4, Search Console and campaign data into clear dashboards and monthly reports with actionable insights.",
    metaDescription: "Analytics and reporting services: GA4, Search Console, KPI dashboards, Excel MIS reports and monthly marketing reports.",
    disclaimer: "All charts and figures on this page are sample / illustrative data, not real client or website statistics.",
    process: [
      { title: "KPIs", text: "Agree on goals and metrics." },
      { title: "Connect", text: "Access GA4, Search Console, ad accounts." },
      { title: "Build", text: "Create dashboards and report templates." },
      { title: "Analyse", text: "Interpret trends and anomalies." },
      { title: "Advise", text: "Recommend next actions." },
    ],
    items: [
      "Google Analytics 4 Reporting", "Google Search Console Reporting", "Website Traffic Analysis", "Organic Traffic Reporting",
      "Conversion Analysis", "Marketing KPI Dashboards", "Excel MIS Reports", "Campaign Performance Reporting",
      "Monthly Marketing Reports", "Data Visualization", "Actionable Insights",
    ].map((t) => ({
      slug: t.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      title: t,
      overview: `${t} presented in a clear, shareable format.`,
      includes: ["Data collection", "Analysis", "Summary and recommendations"],
      benefits: ["Faster, better-informed decisions"],
      deliverables: ["Report or dashboard"],
    })),
    faqs: [
      { q: "Which tools do you report from?", a: "GA4, Search Console, Google Ads, Meta Ads and Excel, depending on your setup." },
    ],
  },
};
