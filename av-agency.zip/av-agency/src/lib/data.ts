import { cache } from "react";
import { dbConfigured, getDb } from "./db";
import { DEFAULT_PLANS, DEFAULT_POSTS, DEFAULT_PROJECTS, type PlanRow, type PostRow, type ProjectRow } from "./defaults";
import { SITE } from "./site";

async function safe<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  if (!dbConfigured) return fallback;
  try {
    return await fn();
  } catch (e) {
    console.error("[db] falling back to defaults:", (e as Error).message);
    return fallback;
  }
}

export const getSettings = cache(async () => {
  const base = { agencyName: SITE.name, tagline: SITE.tagline, contactEmail: SITE.email, whatsappNumber: SITE.whatsapp, location: SITE.location, linkedinUrl: "", instagramUrl: "", facebookUrl: "", gaId: process.env.NEXT_PUBLIC_GA_ID || "", gtmId: process.env.NEXT_PUBLIC_GTM_ID || "", metaPixelId: process.env.NEXT_PUBLIC_META_PIXEL_ID || "" };
  return safe(async () => {
    const s = await getDb().siteSettings.findUnique({ where: { id: "singleton" } });
    if (!s) return base;
    return { ...base, ...Object.fromEntries(Object.entries(s).filter(([k, v]) => v && !["id", "updatedAt"].includes(k))) } as typeof base;
  }, base);
});

export const getPlans = cache(async (): Promise<PlanRow[]> =>
  safe(async () => {
    const rows = await getDb().pricingPlan.findMany({ where: { enabled: true }, orderBy: { sortOrder: "asc" } });
    return rows.length ? rows.map((r) => ({ slug: r.slug, name: r.name, priceInr: r.priceInr, priceUsd: r.priceUsd, priceNote: r.priceNote, features: r.features, custom: r.custom })) : DEFAULT_PLANS;
  }, DEFAULT_PLANS));

export const getProjects = cache(async (): Promise<ProjectRow[]> =>
  safe(async () => {
    const rows = await getDb().portfolioProject.findMany({ where: { published: true }, orderBy: { createdAt: "asc" } });
    return rows.length ? rows : DEFAULT_PROJECTS;
  }, DEFAULT_PROJECTS));

export const getPosts = cache(async (): Promise<PostRow[]> =>
  safe(async () => {
    const rows = await getDb().blogPost.findMany({ where: { published: true }, include: { category: true }, orderBy: { publishedAt: "desc" } });
    return rows.length
      ? rows.map((r) => ({ slug: r.slug, title: r.title, excerpt: r.excerpt, content: r.content, category: r.category.name, readingMinutes: r.readingMinutes, publishedAt: (r.publishedAt ?? r.createdAt).toISOString().slice(0, 10), seoTitle: r.seoTitle ?? undefined, metaDescription: r.metaDescription ?? undefined }))
      : DEFAULT_POSTS;
  }, DEFAULT_POSTS));
