// Outline traced directly from the supplied AV monogram (public/brand/av-logo.png, 863x843).
// Used only to extrude the exact logo geometry in 3D; the 2D logo always uses the original PNG.
export const LOGO_W = 863;
export const LOGO_H = 843;

export const LOGO_OUTER: [number, number][] = [
  [382, 167], [183, 537], [230, 536], [264, 472], [370, 472], [491, 695],
  [687, 328], [508, 328], [527, 363], [622, 364], [555, 490],
];
export const LOGO_HOLES: [number, number][][] = [
  [[318, 372], [350, 434], [285, 435]],
  [[381, 256], [532, 533], [490, 609], [341, 330]],
];
