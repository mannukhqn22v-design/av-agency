export const SITE = {
  name: "Aakash Verma Digital Agency",
  short: "AV Digital",
  founder: "Aakash Verma",
  tagline: "Data-Driven Marketing. Measurable Digital Growth.",
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "aakashverma852787@gmail.com",
  location: "New Delhi, India",
  url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  whatsapp: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "", // digits only, set in .env or admin settings
  description:
    "Founder-led SEO, performance marketing and B2B lead research agency in New Delhi. We help businesses improve online visibility, generate qualified leads and decide with data.",
};

export const NAV = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  {
    label: "Services",
    children: [
      { href: "/services/seo", label: "SEO Services", desc: "Audits, technical & local SEO" },
      { href: "/services/google-ads", label: "Google Ads", desc: "Search, display, PMax, YouTube" },
      { href: "/services/meta-ads", label: "Meta Ads", desc: "Facebook & Instagram campaigns" },
      { href: "/services/b2b-lead-generation", label: "B2B Lead Generation", desc: "Research, enrichment, CRM hygiene" },
      { href: "/services/analytics-reporting", label: "Analytics & Reporting", desc: "GA4, GSC, MIS dashboards" },
    ],
  },
  { href: "/portfolio", label: "Portfolio" },
  { href: "/pricing", label: "Pricing" },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" },
] as const;

export const SERVICE_OPTIONS = [
  "SEO Services",
  "Google Ads",
  "Meta Ads",
  "B2B Lead Generation",
  "Analytics & Reporting",
  "Website SEO Audit",
  "Other / Not sure yet",
];
