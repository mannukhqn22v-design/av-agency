import { z } from "zod";
import { SERVICE_OPTIONS } from "./site";

const clean = (s: string) => s.replace(/[\u0000-\u001f\u007f]/g, " ").trim();

export const enquirySchema = z.object({
  name: z.string().transform(clean).pipe(z.string().min(2, "Please enter your name").max(100)),
  email: z.string().transform(clean).pipe(z.string().email("Enter a valid email").max(160)),
  company: z.string().transform(clean).pipe(z.string().max(120)).optional().or(z.literal("")),
  websiteUrl: z
    .string()
    .transform(clean)
    .refine((v) => v === "" || /^https?:\/\/[^\s.]+\.[^\s]{2,}$/i.test(v), "Enter a valid URL starting with http:// or https://")
    .optional(),
  service: z.string().refine((v) => SERVICE_OPTIONS.includes(v), "Choose a service"),
  budget: z.string().transform(clean).pipe(z.string().max(60)).optional().or(z.literal("")),
  message: z.string().transform(clean).pipe(z.string().min(10, "Please describe your requirements (min 10 characters)").max(3000)),
  contactMethod: z.enum(["EMAIL", "WHATSAPP", "PHONE"]).default("EMAIL"),
  // anti-spam
  hp: z.string().max(200).optional(),
  startedAt: z.number().optional(),
});
export type EnquiryInput = z.infer<typeof enquirySchema>;

export const slugify = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
