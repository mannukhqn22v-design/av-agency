# Aakash Verma Digital Agency: Full-Stack Website

Next.js 16 (App Router) · TypeScript · Tailwind 4 · Framer Motion · Three.js / React Three Fiber · PostgreSQL · Prisma 7

## Quick start (local)
1. `npm install`
2. Create a PostgreSQL database, then `cp .env.example .env` and fill `DATABASE_URL`, `AUTH_SECRET` (`openssl rand -base64 48`), `ADMIN_EMAIL`, `ADMIN_PASSWORD` (12+ chars).
3. `npm run db:migrate` (applies `prisma/migrations`)
4. `npm run db:seed` (creates the admin user + DEMO blog/portfolio/pricing rows, editable in /admin)
5. `npm run dev` → http://localhost:3000, admin at `/admin`

## Production
`npm run build && npm start` (Node 20+). Set all env vars on the host (Vercel, Railway, VPS). Use a managed Postgres.
Set `NEXT_PUBLIC_SITE_URL` to your real domain (sitemap, canonicals, schema use it).
Uploads go to `UPLOAD_DIR`: use a persistent disk/volume (serverless hosts need object storage instead).
The in-memory rate limiter suits one instance; swap for Redis/Upstash when scaling out.

## Email
Set `SMTP_HOST/PORT/USER/PASS/FROM`. Without them, enquiries are still saved and visible in /admin/leads (no email is sent).
For Gmail use an App Password.

## Analytics
Set GA4 / GTM / Meta Pixel IDs in `.env` or /admin/settings. Nothing loads until an ID exists AND the visitor accepts the consent banner.

## WhatsApp
Set `NEXT_PUBLIC_WHATSAPP_NUMBER` or /admin/settings. The button stays hidden until a number is set.

## Brand
The exact supplied AV logo is `public/brand/av-logo.png` (also `src/app/icon.png` favicon). The 3D monogram is extruded from the traced outline of that logo (`src/lib/logo-shape.ts`).

## Roles
SUPER_ADMIN can delete records; EDITOR can create/edit. No public registration. To add admins, insert a row with a bcrypt hash (see `prisma/seed.ts`).

## QA checklist
- [ ] All routes load, no console errors, no horizontal scroll at 390px
- [ ] Contact form: validation, success, duplicate, rate limit; lead appears in /admin/leads
- [ ] Admin login, CSV export, upload (PNG/JPG/WebP only), CRUD for blog/portfolio/pricing/services/settings
- [ ] Theme toggle persists; reduced-motion and mobile show static hero
- [ ] Replace the starter privacy policy with a lawyer-reviewed one
