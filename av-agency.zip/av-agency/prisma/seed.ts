import "dotenv/config";
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import bcrypt from "bcryptjs";
import { DEFAULT_PLANS, DEFAULT_POSTS, DEFAULT_PROJECTS, BLOG_CATEGORIES } from "../src/lib/defaults";

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) });
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

async function main() {
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase();
  const pass = process.env.ADMIN_PASSWORD || "";
  if (!email || pass.length < 12) throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ chars) in .env before seeding.");
  const admin = await db.adminUser.upsert({
    where: { email },
    update: {},
    create: { email, name: "Aakash Verma", passwordHash: await bcrypt.hash(pass, 12), role: "SUPER_ADMIN" },
  });

  await db.siteSettings.upsert({ where: { id: "singleton" }, update: {}, create: { id: "singleton" } });

  const cats: Record<string, string> = {};
  for (const name of BLOG_CATEGORIES) {
    const c = await db.blogCategory.upsert({ where: { slug: slug(name) }, update: {}, create: { slug: slug(name), name } });
    cats[name] = c.id;
  }
  for (const p of DEFAULT_POSTS) {
    await db.blogPost.upsert({
      where: { slug: p.slug }, update: {},
      create: { slug: p.slug, title: p.title, excerpt: p.excerpt, content: p.content, readingMinutes: p.readingMinutes, published: true, publishedAt: new Date(p.publishedAt), categoryId: cats[p.category] ?? cats["Digital Marketing"], authorId: admin.id, seoTitle: p.title, metaDescription: p.excerpt },
    });
  }
  for (const [i, p] of DEFAULT_PROJECTS.entries()) {
    await db.portfolioProject.upsert({ where: { slug: p.slug }, update: {}, create: { ...p, published: true } });
    void i;
  }
  for (const [i, p] of DEFAULT_PLANS.entries()) {
    await db.pricingPlan.upsert({ where: { slug: p.slug }, update: {}, create: { ...p, sortOrder: i } });
  }
  const sc = await db.serviceCategory.upsert({ where: { slug: "digital-marketing" }, update: {}, create: { slug: "digital-marketing", name: "Digital Marketing" } });
  const svc = [["seo", "SEO", "Audits, keyword research, on-page and technical SEO."], ["google-ads", "Google Ads", "Search, display and remarketing campaigns."], ["meta-ads", "Meta Ads", "Facebook and Instagram campaigns."], ["b2b-lead-generation", "B2B Lead Generation", "Prospect research and CRM data hygiene."], ["analytics-reporting", "Analytics & Reporting", "GA4, Search Console and MIS reports."]];
  for (const [i, [s, t, d]] of svc.entries()) {
    await db.service.upsert({ where: { slug: s }, update: {}, create: { slug: s, title: t, summary: d, description: d, features: [], sortOrder: i, categoryId: sc.id } });
  }
  console.log(`Seed complete. Admin user: ${email}. Blog/portfolio/pricing rows are DEMO content you can edit in /admin.`);
}
main().then(() => db.$disconnect()).catch(async (e) => { console.error(e.message); await db.$disconnect(); process.exit(1); });
